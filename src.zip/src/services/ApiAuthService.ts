import axios from 'axios';

const API_BASE_URL = 'https://sandboxapicore.imaginasoft.pt/api/v1';
const USERNAME = 'sandboxapi_nsapi_266844693';
const PASSWORD = 'ieN83R8ilgqPu6RCEsUFdg9H22OzfKG2wjSoSsnt@AqYKsntqJIF&Ux2$2O1';

interface AuthResponse {
  token: string; // Certifique-se de que a API retorna o token neste formato
}

class AuthService {
  private static token: string | null = null; // Cache do token

  private static async fetchAuthToken(): Promise<string> {
    try {
      const response = await axios.post<AuthResponse>(
        `${API_BASE_URL}/Authentication`,
        {
          username: USERNAME,
          password: PASSWORD,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      // Compruebe si el token se devolvió correctamente
      if (!response.data.token) {
        throw new Error('Token no encontrado en la respuesta');
      }

      return response.data.token;
    } catch (error) {
      // Mejorar el manejo de errores
      if (error.response) {
        // Error devuelto por la API
        throw new Error(
          `No se pudo autenticar: ${error.response.status} - ${error.response.data.message || 'Ningún mensaje de error'}`
        );
      } else if (error.request) {
        // Error de conexión
        throw new Error('No se pudo autenticar: no se recibió respuesta del servidor');
      } else {
        // error genérico
        throw new Error('No se pudo autenticar: ' + error.message);
      }
    }
  }

  public static async getAuthToken(): Promise<string> {
    // Si el token ya está en caché, devuélvalo
    if (this.token) {
      return this.token;
    }

    // Si no, obtenga un nuevo token
    this.token = await this.fetchAuthToken();
    return this.token;
  }

  // Método para borrar la caché de tokens (útil para cerrar sesión o tokens caducados)
  public static clearToken(): void {
    this.token = null;
  }
}

export default AuthService;