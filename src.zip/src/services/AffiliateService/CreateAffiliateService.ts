import AppError from "../../errors/AppError";
import Company from "../../models/Company";
import Affiliate from "../../models/Affiliate";
import AffiliateLink from "../../models/AffiliateLink";
import { generateAffiliateCode } from "../../utils/affiliateUtils";

interface Request {
  companyId: number;
  commissionRate?: number;
  minWithdrawAmount?: number;
}

const CreateAffiliateService = async ({
  companyId,
  commissionRate = 10.00,
  minWithdrawAmount = 50.00
}: Request): Promise<Affiliate> => {
  // Comprobar si la empresa existe
  const company = await Company.findByPk(companyId);
  if (!company) {
    throw new AppError("Empresa no encontrada", 404);
  }

  // Comprueba si ya eres afiliado
  const existingAffiliate = await Affiliate.findOne({
    where: { companyId }
  });
  if (existingAffiliate) {
    throw new AppError("La empresa ya es afiliada.", 400);
  }

  // Generar código de afiliado único
  const affiliateCode = await generateAffiliateCode();

  // Crear afiliado
  const affiliate = await Affiliate.create({
    companyId,
    affiliateCode,
    commissionRate,
    minWithdrawAmount,
    totalEarned: 0,
    totalWithdrawn: 0,
    status: "active"
  });

  // Crear enlace de referencia predeterminado
  await AffiliateLink.create({
    affiliateId: affiliate.id,
    code: affiliateCode,
    url: `${process.env.FRONTEND_URL}/cadastro?aff=${affiliateCode}`,
    clicks: 0,
    signups: 0,
    conversions: 0,
    trackingData: {}
  });

  return affiliate;
};

export default CreateAffiliateService;
