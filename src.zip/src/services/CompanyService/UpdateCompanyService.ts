import AppError from "../../errors/AppError";
import Company from "../../models/Company";
import Setting from "../../models/Setting";
import User from "../../models/User";
import Invoices from "../../models/Invoices";
import Plan from "../../models/Plan";

interface CompanyData {
  name: string;
  id?: number | string;
  phone?: string;
  email?: string;
  status?: boolean;
  planId?: number;
  campaignsEnabled?: boolean;
  dueDate?: string;
  recurrence?: string;
  document?: string;
  paymentMethod?: string;
  password?: string;
}

const UpdateCompanyService = async (
  companyData: CompanyData
): Promise<Company> => {

  const company = await Company.findByPk(companyData.id);
  const {
    name,
    phone,
    email,
    status,
    planId,
    campaignsEnabled,
    dueDate,
    recurrence,
    document,
    paymentMethod,
    password
  } = companyData;

  if (!company) {
    throw new AppError("ERR_NO_COMPANY_FOUND", 404);
  }

  // Actualice la factura abierta si existe y si se ha modificado el plan. 
  if (planId) {
    const openInvoices = await Invoices.findAll({
      where: {
        status: "open",
        companyId: company.id,
      },
    });
    
    // Cancele las facturas duplicadas si hay más de una.
    if (openInvoices.length > 1) {
      for (const invoice of openInvoices.slice(1)) {
        await invoice.update({ status: "cancelled" });
      }
    }
    
    const plan = await Plan.findByPk(planId);
    
    if (!plan) {
      throw new Error("Plan no encontrado.");
    }
    
    // Actualice la factura abierta si existe.
    const openInvoice = openInvoices[0];
    if (openInvoice) {
      const valuePlan = plan.amount.replace(",", ".");
      await openInvoice.update({
        value: valuePlan,
        detail: plan.name,
        users: plan.users,
        connections: plan.connections,
        queues: plan.queues,
        dueDate: dueDate,
      });
    }
    // Si no hay ninguna factura abierta, simplemente continúa sin errores.
  }

  // Compruebe si existe otro usuario con este correo electrónico en OTRA empresa.
  const existUser = await User.findOne({
    where: {
      email: email
    }
  });

  // Solo se genera un error si se encuentra un usuario con este correo electrónico en OTRA empresa.
  if (existUser && existUser.companyId !== company.id) {
    throw new AppError("¡El usuario ya existe con este correo electrónico!", 404)
  }

  const user = await User.findOne({
    where: {
      companyId: company.id,
      email: company.email
    }
  });

  if (!user) {
    throw new AppError("ERR_NO_USER_FOUND", 404)
  }
  
  await user.update({ email, password });


  await company.update({
    name,
    phone,
    email,
    status,
    planId,
    dueDate,
    recurrence,
    document,
    paymentMethod
  });

  if (companyData.campaignsEnabled !== undefined) {
    const [setting, created] = await Setting.findOrCreate({
      where: {
        companyId: company.id,
        key: "campaignsEnabled"
      },
      defaults: {
        companyId: company.id,
        key: "campaignsEnabled",
        value: `${campaignsEnabled}`
      }
    });
    if (!created) {
      await setting.update({ value: `${campaignsEnabled}` });
    }
  }

  return company;
};

export default UpdateCompanyService;
