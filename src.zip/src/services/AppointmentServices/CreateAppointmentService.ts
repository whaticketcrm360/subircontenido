import * as Yup from "yup";
import AppError from "../../errors/AppError";
import Appointment from "../../models/Appointment";
import UserSchedule from "../../models/UserSchedule";
import User from "../../models/User";
import UserGoogleCalendarIntegration from "../../models/UserGoogleCalendarIntegration";
import { Op } from "sequelize";
import { createGoogleCalendarEvent } from "../../helpers/googleCalendarClient";

interface CreateAppointmentData {
  title: string;
  description?: string;
  startDatetime: Date | string;
  durationMinutes: number;
  status?: string;
  scheduleId: number;
  serviceId?: number;
  clientId?: number;
  contactId?: number;
  companyId: number;
}

const CreateAppointmentService = async (
  data: CreateAppointmentData
): Promise<Appointment> => {
  const schema = Yup.object().shape({
    title: Yup.string().required("El titulo es obligatorio").max(200),
    description: Yup.string().nullable(),
    startDatetime: Yup.date().required("La fecha/hora de inicio es obligatoria"),
    durationMinutes: Yup.number().required("La duración es obligatoria").min(1),
    status: Yup.string().oneOf(["scheduled", "confirmed", "completed", "cancelled", "no_show"]).default("scheduled"),
    scheduleId: Yup.number().required("La agenda es obligatoria."),
    serviceId: Yup.number().nullable(),
    clientId: Yup.number().nullable(),
    contactId: Yup.number().nullable(),
    companyId: Yup.number().required()
  });

  try {
    await schema.validate(data);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const schedule = await UserSchedule.findOne({
    where: { id: data.scheduleId, companyId: data.companyId },
    include: [{ model: User, as: "user" }]
  });

  if (!schedule) {
    throw new AppError("Calendario no encontrado", 404);
  }

  if (!schedule.active) {
    throw new AppError("Este calendario no está activo", 400);
  }

  const startDatetime = new Date(data.startDatetime);
  const endDatetime = new Date(startDatetime.getTime() + data.durationMinutes * 60000);

  const user = schedule.user;
  const userStartWork = user?.startWork || "00:00";
  const userEndWork = user?.endWork || "23:59";
  const userWorkDays = user?.workDays || "0,1,2,3,4,5,6";
  const userLunchStart = user?.lunchStart || null;
  const userLunchEnd = user?.lunchEnd || null;

  // Validar jornada laboral
  const dayOfWeek = startDatetime.getDay(); // 0 = Domingo, 6 = Sábado
  const workDaysArray = userWorkDays.split(",").map(d => parseInt(d.trim(), 10));
  
  if (!workDaysArray.includes(dayOfWeek)) {
    const dayNames = ["Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sábado"];
    throw new AppError(
      `El profesional no trabaja ese día. (${dayNames[dayOfWeek]}). Días laborables: ${workDaysArray.map(d => dayNames[d]).join(", ")}`,
      400
    );
  }

  // Validar horas de trabajo
  const startTime = startDatetime.toTimeString().substring(0, 5);
  const endTime = endDatetime.toTimeString().substring(0, 5);

  if (startTime < userStartWork || endTime > userEndWork) {
    throw new AppError(
      `La cita debe ser dentro del horario laboral del profesional. (${userStartWork} - ${userEndWork})`,
      400
    );
  }

  // Validar la hora del almuerzo
  if (userLunchStart && userLunchEnd) {
    // Comprueba si la cita entra en conflicto con la hora del almuerzo.
    const lunchStartMinutes = parseInt(userLunchStart.split(":")[0], 10) * 60 + parseInt(userLunchStart.split(":")[1], 10);
    const lunchEndMinutes = parseInt(userLunchEnd.split(":")[0], 10) * 60 + parseInt(userLunchEnd.split(":")[1], 10);
    
    const appointmentStartMinutes = startDatetime.getHours() * 60 + startDatetime.getMinutes();
    const appointmentEndMinutes = endDatetime.getHours() * 60 + endDatetime.getMinutes();

    // Comprobaciones de superposición con el horario del almuerzo.
    const overlapsLunch = (
      (appointmentStartMinutes >= lunchStartMinutes && appointmentStartMinutes < lunchEndMinutes) ||
      (appointmentEndMinutes > lunchStartMinutes && appointmentEndMinutes <= lunchEndMinutes) ||
      (appointmentStartMinutes <= lunchStartMinutes && appointmentEndMinutes >= lunchEndMinutes)
    );

    if (overlapsLunch) {
      throw new AppError(
        `La cita no se puede programar durante la hora del almuerzo del profesional. (${userLunchStart} - ${userLunchEnd})`,
        400
      );
    }
  }

  const existingAppointments = await Appointment.findAll({
    where: {
      scheduleId: data.scheduleId,
      status: { [Op.notIn]: ["cancelled", "no_show"] }
    }
  });

  for (const existing of existingAppointments) {
    const existingStart = new Date(existing.startDatetime).getTime();
    const existingEnd = existingStart + existing.durationMinutes * 60000;
    const newStart = startDatetime.getTime();
    const newEnd = endDatetime.getTime();

    if (
      (newStart >= existingStart && newStart < existingEnd) ||
      (newEnd > existingStart && newEnd <= existingEnd) ||
      (newStart <= existingStart && newEnd >= existingEnd)
    ) {
      throw new AppError("Ya hay cita a esta hora", 400);
    }
  }

  const appointment = await Appointment.create({
    title: data.title,
    description: data.description || null,
    startDatetime,
    durationMinutes: data.durationMinutes,
    status: data.status || "scheduled",
    scheduleId: data.scheduleId,
    serviceId: data.serviceId || null,
    clientId: data.clientId || null,
    contactId: data.contactId || null,
    companyId: data.companyId
  });

  // Comprueba si el calendario tiene integración con Google Calendar
  if (schedule.userGoogleCalendarIntegrationId) {
    try {
      console.log("DEBUG - Crear un evento en Google Calendar para una cita:", appointment.id);
      
      const integration = await UserGoogleCalendarIntegration.findOne({
        where: { id: schedule.userGoogleCalendarIntegrationId }
      });

      if (integration && integration.accessToken) {
        console.log("DEBUG - Usando la integración:", {
          email: integration.email,
          calendarId: integration.calendarId,
          googleUserId: integration.googleUserId
        });
        
        // Busque información adicional para obtener una descripción completa
        let fullDescription = data.description || "";
        
        if (data.serviceId) {
          // TODO: Buscar información del servicio
          fullDescription += fullDescription ? "\n\n" : "";
          fullDescription += `Servicio ID: ${data.serviceId}`;
        }
        
        if (data.clientId) {
          // TODO: Obtener información del cliente
          fullDescription += fullDescription ? "\n\n" : "";
          fullDescription += `Cliente ID: ${data.clientId}`;
        }
        
        if (data.contactId) {
          // TODO: Buscar información de contacto
          fullDescription += fullDescription ? "\n\n" : "";
          fullDescription += `Contacto ID: ${data.contactId}`;
        }

        fullDescription += fullDescription ? "\n\n" : "";
        fullDescription += `Estado: ${appointment.status}`;
        fullDescription += `\nProgramado a través del sistema en: ${appointment.createdAt.toLocaleDateString('es')}`;

        const googleEvent = await createGoogleCalendarEvent(
          integration.accessToken,
          integration.refreshToken,
          {
            summary: data.title,
            description: fullDescription,
            start: {
              dateTime: startDatetime.toISOString(),
              timeZone: 'America/Mexico_City'
            },
            end: {
              dateTime: endDatetime.toISOString(),
              timeZone: 'America/Mexico_City'
            }
          },
          integration.calendarId
        );

        if (googleEvent && googleEvent.id) {
          // Guardar ID de evento de Google Calendar
          await appointment.update({ googleEventId: googleEvent.id });
          console.log("DEBUG - Evento creado en Google Calendar:", googleEvent.id);
        }
      }
    } catch (error) {
      console.error("ERROR - No se pudo crear el evento en Google Calendar:", error);
      // No falle la creación de citas si falla la sincronización
    }
  }

  return appointment;
};

export default CreateAppointmentService;
