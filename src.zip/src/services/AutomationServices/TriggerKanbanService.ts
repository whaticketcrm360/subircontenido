import { Op } from "sequelize";
import moment from "moment";
import Automation from "../../models/Automation";
import AutomationAction from "../../models/AutomationAction";
import Contact from "../../models/Contact";
import Ticket from "../../models/Ticket";
import TicketTag from "../../models/TicketTag";
import Tag from "../../models/Tag";
import logger from "../../utils/logger";
import { processAutomationForContact } from "./ProcessAutomationService";

// Automatizaciones de tiempos de procesos en Kanban (el avance es de X horas en una fase)
export const processKanbanTimeAutomations = async (companyId: number): Promise<void> => {
  try {
    // Búsqueda de automatizaciones de tiempo kanban activas
    const automations = await Automation.findAll({
      where: {
        companyId,
        triggerType: "kanban_time",
        isActive: true
      },
      include: [
        {
          model: AutomationAction,
          as: "actions",
          separate: true,
          order: [["order", "ASC"]]
        }
      ]
    });

    if (automations.length === 0) {
      return;
    }

    for (const automation of automations) {
      const { tagId, hoursInStage } = automation.triggerConfig || {};

      if (!tagId || !hoursInStage) {
        continue;
      }

      // Calcular fecha límite (tickets que han estado en la etiqueta por más de X horas)
      const limitDate = moment().subtract(hoursInStage, "hours").toDate();

      // Busque tickets que hayan estado en la etiqueta por más tiempo que el límite
      const ticketTags = await TicketTag.findAll({
        where: {
          tagId,
          createdAt: { [Op.lte]: limitDate }
        },
        include: [
          {
            model: Ticket,
            as: "ticket",
            where: {
              companyId,
              status: { [Op.notIn]: ["closed", "lgpd", "nps"] }
            },
            include: [
              { model: Contact, as: "contact" }
            ]
          }
        ]
      });

      for (const ticketTag of ticketTags) {
        const ticket = (ticketTag as any).ticket;
        if (!ticket || !ticket.contact) continue;

        try {
          await processAutomationForContact(automation, ticket.contact, ticket);
          logger.info(`[Automation KanbanTime] Automatización ${automation.id} procesado para boleto ${ticket.id}`);
        } catch (error: any) {
          logger.error(`[Automation KanbanTime] Error: ${error.message}`);
        }
      }
    }
  } catch (error: any) {
    logger.error(`[Automation KanbanTime] error general: ${error.message}`);
  }
};

// Automatizaciones de procesos cuando el cliente potencial entra en una fase Kanban
export const processKanbanStageAutomation = async (
  ticketId: number,
  tagId: number,
  companyId: number
): Promise<void> => {
  try {
    // Buscar automatizaciones para esta etiqueta/fase
    const automations = await Automation.findAll({
      where: {
        companyId,
        triggerType: "kanban_stage",
        isActive: true
      },
      include: [
        {
          model: AutomationAction,
          as: "actions",
          separate: true,
          order: [["order", "ASC"]]
        }
      ]
    });

    // Filtrar automatizaciones que coincidan con la etiqueta
    const matchingAutomations = automations.filter(a => {
      const config = a.triggerConfig || {};
      return config.tagId === tagId || config.tagIds?.includes(tagId);
    });

    if (matchingAutomations.length === 0) {
      return;
    }

    // Buscar ticket con contacto
    const ticket = await Ticket.findByPk(ticketId, {
      include: [{ model: Contact, as: "contact" }]
    });

    if (!ticket || !ticket.contact) {
      return;
    }

    for (const automation of matchingAutomations) {
      try {
        await processAutomationForContact(automation, ticket.contact, ticket);
        logger.info(`[Automation KanbanStage] Automatización ${automation.id} procesado para ticket ${ticketId}`);
      } catch (error: any) {
        logger.error(`[Automation KanbanStage] Error: ${error.message}`);
      }
    }
  } catch (error: any) {
    logger.error(`[Automation KanbanStage] error general: ${error.message}`);
  }
};

export default {
  processKanbanTimeAutomations,
  processKanbanStageAutomation
};
