import { Op } from "sequelize";
import moment from "moment";
import Automation from "../../models/Automation";
import AutomationAction from "../../models/AutomationAction";
import Contact from "../../models/Contact";
import Ticket from "../../models/Ticket";
import Message from "../../models/Message";
import logger from "../../utils/logger";
import { processAutomationForContact } from "./ProcessAutomationService";

// Procesar automatizaciones de "sin respuesta" (el cliente potencial no ha respondido en X horas)
export const processNoResponseAutomations = async (companyId: number): Promise<void> => {
  try {
    // Buscar automatizaciones activas de "sin respuesta"
    const automations = await Automation.findAll({
      where: {
        companyId,
        triggerType: "no_response",
        isActive: true
      },
      include: [
        {
          model: AutomationAction,
          as: "actions",
          separate: true,
          order: [["order", "ASC"]]
        }
      ]
    });

    if (automations.length === 0) {
      return;
    }

    for (const automation of automations) {
      const { hoursWithoutResponse, onlyOpenTickets } = automation.triggerConfig || {};

      if (!hoursWithoutResponse) {
        continue;
      }

      // Calcular fecha límite
      const limitDate = moment().subtract(hoursWithoutResponse, "hours").toDate();

      // Estado del ticket
      const statusCondition = onlyOpenTickets 
        ? { status: "open" }
        : { status: { [Op.notIn]: ["closed", "lgpd", "nps"] } };

      // Buscar tickets que no han recibido respuesta del cliente
      const tickets = await Ticket.findAll({
        where: {
          companyId,
          ...statusCondition,
          updatedAt: { [Op.lte]: limitDate }
        },
        include: [
          { model: Contact, as: "contact" }
        ]
      });

      for (const ticket of tickets) {
        // Comprobar si el último mensaje fue enviado por la empresa (fromMe = true)
        const lastMessage = await Message.findOne({
          where: { ticketId: ticket.id },
          order: [["createdAt", "DESC"]]
        });

        // Si el último mensaje fue del cliente, no activar
        if (lastMessage && !lastMessage.fromMe) {
          continue;
        }

        // Si el último mensaje fue de la empresa y el cliente no respondió
        if (lastMessage && lastMessage.fromMe) {
          const messageDate = moment(lastMessage.createdAt);
          const hoursSinceMessage = moment().diff(messageDate, "hours");

          if (hoursSinceMessage >= hoursWithoutResponse) {
            try {
              await processAutomationForContact(automation, ticket.contact, ticket);
              logger.info(`[Automation NoResponse] Automatización ${automation.id} procesado para el ticket ${ticket.id}`);
            } catch (error: any) {
              logger.error(`[Automation NoResponse] Error: ${error.message}`);
            }
          }
        }
      }
    }
  } catch (error: any) {
    logger.error(`[Automation NoResponse] Error general: ${error.message}`);
  }
};

export default processNoResponseAutomations;
