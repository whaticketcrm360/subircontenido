import { Op } from "sequelize";
import Company from "../../models/Company";
import AutomationExecution from "../../models/AutomationExecution";
import AutomationAction from "../../models/AutomationAction";
import AutomationLog from "../../models/AutomationLog";
import Contact from "../../models/Contact";
import Ticket from "../../models/Ticket";
import logger from "../../utils/logger";
import { executeAction, getCampaignSettings, isWithinDispatchHours } from "./ProcessAutomationService";
import processBirthdayAutomations from "./TriggerBirthdayService";
import { processKanbanTimeAutomations } from "./TriggerKanbanService";
import processNoResponseAutomations from "./TriggerNoResponseService";

// Ejecutar automatizaciones programadas que estén pendientes
export const executeScheduledAutomations = async (): Promise<void> => {
  try {
    const now = new Date();

    // Buscar ejecuciones programadas que hayan pasado su tiempo programado
    const executions = await AutomationExecution.findAll({
      where: {
        status: "scheduled",
        scheduledAt: { [Op.lte]: now }
      },
      include: [
        { model: AutomationAction, as: "automationAction" },
        { model: Contact, as: "contact" },
        { model: Ticket, as: "ticket" }
      ],
      limit: 100,
      order: [["scheduledAt", "ASC"]]
    });

    if (executions.length === 0) {
      return;
    }

    logger.info(`[Automation Job] Tratamiento ${executions.length} ejecuciones programadas`);

    for (const execution of executions) {
      try {
        // Marcar como en ejecución
        await execution.update({
          status: "running",
          attempts: execution.attempts + 1,
          lastAttemptAt: new Date()
        });

        const action = execution.automationAction;
        const contact = execution.contact;
        const ticket = execution.ticket;

        if (!action || !contact) {
          await execution.update({
            status: "failed",
            error: "Acción o contacto no encontrado"
          });
          continue;
        }

        // realizar la acción
        const result = await executeAction(action, contact, ticket, contact.companyId);

        // Ejecución de actualización
        await execution.update({
          status: result.success ? "completed" : "failed",
          completedAt: result.success ? new Date() : null,
          error: result.success ? null : result.message
        });

        // Registro de actualización
        await AutomationLog.update(
          {
            status: result.success ? "completed" : "failed",
            executedAt: new Date(),
            result: result,
            error: result.success ? null : result.message
          },
          {
            where: {
              automationId: execution.automationId,
              contactId: contact.id,
              status: "pending"
            }
          }
        );

        logger.info(`[Automation Job] Ejecución ${execution.id} ${result.success ? "terminado" : "fallido"}: ${result.message}`);
      } catch (error: any) {
        await execution.update({
          status: "failed",
          error: error.message
        });
        logger.error(`[Automation Job] error de ejecución ${execution.id}: ${error.message}`);
      }
    }
  } catch (error: any) {
    logger.error(`[Automation Job] error general: ${error.message}`);
  }
};

const getActiveCompanyIds = async (): Promise<number[]> => {
  const companies = await Company.findAll({
    where: { status: true },
    attributes: ["id"]
  });
  return companies.map(company => company.id);
};

const runPerCompany = async (
  jobLabel: string,
  triggerType: string,
  handler: (companyId: number) => Promise<void>
): Promise<void> => {
  const companyIds = await getActiveCompanyIds();

  for (const companyId of companyIds) {
    try {
      const settings = await getCampaignSettings(companyId);
      if (!isWithinDispatchHours(settings, triggerType)) {
        logger.debug(
          `[Automation Job] Empresa ${companyId} fuera de la ventana para ${jobLabel} (${triggerType})`
        );
        continue;
      }
      await handler(companyId);
    } catch (error: any) {
      logger.error(`[Automation Job] error en la empresa ${companyId} (${jobLabel}): ${error.message}`);
    }
  }
};

// Solo procesa ejecuciones programadas
export const runAutomationJob = async (): Promise<void> => {
  try {
    logger.info("[Automation Job] Ejecutando cola de ejecución programada...");
    await executeScheduledAutomations();
    logger.info("[Automation Job] Ejecuciones programadas completadas");
  } catch (error: any) {
    logger.error(`[Automation Job] error general: ${error.message}`);
  }
};

export const runBirthdayAutomationJob = async (): Promise<void> => {
  logger.info("[Automation Birthday Job] Iniciando procesamiento...");
  await runPerCompany("birthday", "birthday", processBirthdayAutomations);
  logger.info("[Automation Birthday Job] Procesamiento completado");
};

export const runKanbanAutomationJob = async (): Promise<void> => {
  logger.info("[Automation Kanban Job] Iniciando procesamiento...");
  await runPerCompany("kanban_time", "kanban_time", processKanbanTimeAutomations);
  logger.info("[Automation Kanban Job] Procesamiento completado");
};

export const runNoResponseAutomationJob = async (): Promise<void> => {
  logger.info("[Automation NoResponse Job] Iniciando procesamiento...");
  await runPerCompany("no_response", "no_response", processNoResponseAutomations);
  logger.info("[Automation NoResponse Job] Procesamiento completado");
};

export default runAutomationJob;
