import { Router } from "express";
import isAuth from "../middleware/isAuth";
import * as UserGoogleCalendarController from "../controllers/UserGoogleCalendarController";

const router = Router();

// Obtenga la URL de autenticación de Google para un usuario específico
router.get("/auth-url", isAuth, UserGoogleCalendarController.getUserAuthUrl);

// Devolución de llamada de Google OAuth para un usuario específico
router.get("/oauth-callback", UserGoogleCalendarController.userOauthCallback);

// Obtener la incorporación de usuarios actuales
router.get("/integration", isAuth, UserGoogleCalendarController.getUserIntegration);

// Desconectar la integración de usuario actual
router.delete("/integration", isAuth, UserGoogleCalendarController.disconnectUserIntegration);

// Cree una incorporación de usuarios basada en la empresa
router.post("/create-from-company", isAuth, UserGoogleCalendarController.createFromCompanyIntegration);

// Vincular Google Calendar al calendario de un usuario
router.post("/link-schedule", isAuth, UserGoogleCalendarController.linkCalendarToSchedule);

// Desvincular Google Calendar del calendario de un usuario
router.delete("/unlink-schedule", isAuth, UserGoogleCalendarController.unlinkCalendarFromSchedule);

export default router;
