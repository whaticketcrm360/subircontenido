import { Router } from "express";
import * as ExternalApiController from "../controllers/ExternalApiController";
import isAuth from "../middleware/isAuth";

const externalApiRoutes = Router();

// Rutas públicas (no requieren autenticación)
externalApiRoutes.post("/login", ExternalApiController.login);
externalApiRoutes.post("/refresh", ExternalApiController.refresh);

// Rutas protegidas (requieren autenticación)
externalApiRoutes.post("/logout", isAuth, ExternalApiController.logout);
externalApiRoutes.get("/verify", isAuth, ExternalApiController.verify);

export default externalApiRoutes;
