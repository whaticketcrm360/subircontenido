import { Router } from "express";
import UserPagePermissionController from "../controllers/UserPagePermissionController";
import isAuth from "../middleware/isAuth";

const router = Router();

// Listar todas las páginas disponibles en el sistema.
router.get(
  "/pages/list",
  isAuth,
  UserPagePermissionController.listAvailablePages
);

// Obtiene permisos de un usuario específico
router.get(
  "/users/:userId/page-permissions",
  isAuth,
  UserPagePermissionController.getUserPermissions
);

// Establece los permisos de un usuario
router.post(
  "/users/:userId/page-permissions",
  isAuth,
  UserPagePermissionController.setUserPermissions
);

// Comprueba si el usuario actual tiene acceso a una página específica
router.get(
  "/check-page-access",
  isAuth,
  UserPagePermissionController.checkPageAccess
);

// Obtiene páginas a las que el usuario actual puede acceder (para armar el menú)
router.get(
  "/user-accessible-pages",
  isAuth,
  UserPagePermissionController.getUserAccessiblePages
);

export default router;
