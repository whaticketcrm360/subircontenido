import express from "express";
import isAuth from "../middleware/isAuth";
import * as TutorialVideoController from "../controllers/TutorialVideoController";

const tutorialVideoRoutes = express.Router();

// Middleware autenticación para todas las rutas
tutorialVideoRoutes.use(isAuth);

// GET /tutorial-videos - Lista de videos tutoriales
tutorialVideoRoutes.get("/", TutorialVideoController.index);

// GET /tutorial-videos/:tutorialVideoId - Buscar vídeo específico
tutorialVideoRoutes.get("/:tutorialVideoId", TutorialVideoController.show);

// POST /tutorial-videos - Crear nuevo vídeo tutorial
tutorialVideoRoutes.post("/", TutorialVideoController.store);

// PUT /tutorial-videos/:tutorialVideoId - Actualizar vídeotutorial
tutorialVideoRoutes.put("/:tutorialVideoId", TutorialVideoController.update);

// DELETE /tutorial-videos/:tutorialVideoId - Eliminar vídeo tutorial
tutorialVideoRoutes.delete("/:tutorialVideoId", TutorialVideoController.remove);

export default tutorialVideoRoutes;
