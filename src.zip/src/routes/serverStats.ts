import { Router } from 'express';
import si from 'systeminformation';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const cpu = await si.currentLoad();
    const mem = await si.mem();
    const disk = await si.fsSize();

    res.json({
      cpu: cpu.currentLoad.toFixed(2),
      ram: ((mem.active / mem.total) * 100).toFixed(2),
      disks: disk.map(d => ({
        fs: d.fs,
        type: d.type,
        used: ((d.used / d.size) * 100).toFixed(2)
      }))
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error obteniendo métricas del servidor' });
  }
});

export default router;