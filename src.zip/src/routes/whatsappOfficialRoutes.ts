import express from "express";
import isAuth from "../middleware/isAuth";
import multer from "multer";
import uploadConfig from "../config/upload";
import * as WhatsAppOfficialController from "../controllers/WhatsAppOfficialController";
import {
  officialMediaUpload,
  deleteOfficialMedia
} from "../services/WhatsAppOfficial/uploadMediaAttachment";

const whatsappOfficialRoutes = express.Router();
const upload = multer(uploadConfig);

// Conexión oficial CRUD
whatsappOfficialRoutes.post("/whatsapp-official", isAuth, WhatsAppOfficialController.storeOfficial);
whatsappOfficialRoutes.put("/whatsapp-official/:whatsappId", isAuth, WhatsAppOfficialController.updateOfficial);
whatsappOfficialRoutes.delete("/whatsapp-official/:whatsappId", isAuth, WhatsAppOfficialController.removeOfficial);

// enviando mensajes
whatsappOfficialRoutes.post(
  "/whatsapp-official/:ticketId/message",
  isAuth,
  upload.array("medias"),
  WhatsAppOfficialController.sendMessage
);

whatsappOfficialRoutes.post(
  "/whatsapp-official/:whatsappId/media-upload",
  isAuth,
  upload.array("medias"),
  officialMediaUpload
);

whatsappOfficialRoutes.delete(
  "/whatsapp-official/:whatsappId/media-upload",
  isAuth,
  deleteOfficialMedia
);

// Meta webhook (sin isAuth como lo llama Facebook)
whatsappOfficialRoutes.get("/webhook/whatsapp-official", WhatsAppOfficialController.webhookOfficial);
whatsappOfficialRoutes.post("/webhook/whatsapp-official", WhatsAppOfficialController.webhookOfficial);

export default whatsappOfficialRoutes;
