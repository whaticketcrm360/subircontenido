import { Router } from "express";
import { authenticate, authCallback, getAuthStatus, testConnection, executeOperation } from "../controllers/GoogleSheetsController";

const router = Router();

// Autenticación
router.post("/auth", authenticate);
router.get("/auth/callback", authCallback);
router.get("/auth-status", getAuthStatus);

// Pruebas y operaciones
router.post("/test", testConnection);
router.post("/execute", executeOperation);

export default router;
