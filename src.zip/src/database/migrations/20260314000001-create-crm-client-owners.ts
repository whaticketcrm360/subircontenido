import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("crm_client_owners", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      client_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "crm_clients",
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Users",
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    // Adicionar índice único para evitar duplicatas
    await queryInterface.addIndex("crm_client_owners", ["client_id", "user_id"], {
      unique: true,
      name: "crm_client_owners_client_user_unique"
    });

    // Migrar dados existentes de ownerUserId para a nova tabela
    await queryInterface.sequelize.query(`
      INSERT INTO crm_client_owners (client_id, user_id, created_at, updated_at)
      SELECT id, owner_user_id, NOW(), NOW()
      FROM crm_clients
      WHERE owner_user_id IS NOT NULL
    `);
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.dropTable("crm_client_owners");
  }
};
