import { Request, Response } from "express";
import isAuth from "../middleware/isAuth";
import * as NotificationController from "../controllers/NotificationController";

// Middleware para registrar dispositivo móvil
export const registerMobileDevice = async (req: Request, res: Response) => {
  try {
    const { deviceToken, platform } = req.body;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    if (!deviceToken || !platform) {
      return res.status(400).json({ error: "Se requieren token de dispositivo y plataforma" });
    }

    await NotificationController.registerDevice(req, res);
  } catch (error) {
    console.error("Error al registrar el dispositivo móvil:", error);
    return res.status(500).json({ error: "Error Interno del Servidor" });
  }
};

// Middleware para eliminar dispositivo móvil
export const unregisterMobileDevice = async (req: Request, res: Response) => {
  try {
    const { deviceToken } = req.body;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    await NotificationController.unregisterDevice(req, res);
  } catch (error) {
    console.error("Error al cancelar el registro del dispositivo móvil:", error);
    return res.status(500).json({ error: "Error Interno del Servidor" });
  }
};
