import { verify } from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";

import AppError from "../errors/AppError";
import authConfig from "../config/auth";

import { getIO } from "../libs/socket";
import ShowUserService from "../services/UserServices/ShowUserService";
import { updateUser } from "../helpers/updateUser";
// import { moment} from "moment-timezone"

interface TokenPayload {
  id: string;
  username: string;
  profile: string;
  companyId: number;
  iat: number;
  exp: number;
}

const isAuth = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    throw new AppError("ERR_SESSION_EXPIRED", 401);
  }

  // const check = await verifyHelper();

  // if (!check) {
  //   throw new AppError("ERR_SYSTEM_INVALID", 401);
  // }

  const [, token] = authHeader.split(" ");

  try {
    const decoded = verify(token, authConfig.secret);
    const { id, profile, companyId } = decoded as TokenPayload;

    updateUser(id, companyId);

    // Obtener tipo de usuario de la base de datos
    const user = await ShowUserService(id, companyId);

    req.user = {
      id,
      profile,
      companyId,
      userType: user.userType
    };
  } catch (err: any) {
    // Registro de errores para depuración
    console.error("Auth error:", err.name, err.message);
    
    if (err.name === "TokenExpiredError") {
      throw new AppError("ERR_SESSION_EXPIRED", 401);
    } else if (err.name === "JsonWebTokenError") {
      throw new AppError("ERR_INVALID_TOKEN", 401);
    } else {
      throw new AppError(
        "Token no válido. Intentaremos asignar uno nuevo en la próxima solicitud.",
        403
      );
    }
  }

  return next();
};

export default isAuth;