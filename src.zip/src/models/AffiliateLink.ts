import {
  Table,
  Column,
  CreatedAt,
  Model,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  DataType,
  Default,
  BelongsTo
} from "sequelize-typescript";

@Table
class AffiliateLink extends Model<AffiliateLink> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  affiliateId: number;

  @Column({ unique: true })
  code: string;

  @Column
  url: string;

  @Default(0)
  @Column
  clicks: number;

  @Default(0)
  @Column
  signups: number;

  @Default(0)
  @Column
  conversions: number; // Inscripciones que realmente pagaron

  @Column(DataType.JSON)
  trackingData: any; // Datos de seguimiento (IP, agente de usuario, etc.)

  @CreatedAt
  createdAt: Date;

  // Carga diferida para evitar la dependencia circular
  public getAffiliate(): Promise<any> {
    const Affiliate = require("./Affiliate").default;
    return Affiliate.findByPk(this.affiliateId);
  }
}

export default AffiliateLink;
