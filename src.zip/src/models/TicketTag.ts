import {
  Table,
  Column,
  CreatedAt,
  UpdatedAt,
  Model,
  ForeignKey,
  BelongsTo,
  BeforeDestroy
} from "sequelize-typescript";
import Tag from "./Tag";
import Ticket from "./Ticket";

@Table({
  tableName: 'TicketTags'
})
class TicketTag extends Model<TicketTag> {
  @ForeignKey(() => Ticket)
  @Column
  ticketId: number;

  @ForeignKey(() => Tag)
  @Column
  tagId: number;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @BelongsTo(() => Ticket)
  ticket: Ticket;

  @BelongsTo(() => Tag)
  tag: Tag;

  // CORRECCIÓN KANBAN: Bloquear la eliminación de etiquetas de tickets cerrados
  @BeforeDestroy
  static async preventDeleteOnClosedTickets(instance: TicketTag) {
    const ticket = await Ticket.findByPk(instance.ticketId);
    if (ticket && ticket.status === "closed") {
      console.log(`🔴 CORRECCIÓN KANBAN: Bloqueo de eliminación de etiquetas ${instance.tagId} del ticket ${instance.ticketId} - el ticket está cerrado`);
      throw new Error("No se permite quitar etiquetas de tickets cerrados");
    }
  }
}

export default TicketTag;
