import {
  Table,
  Column,
  CreatedAt,
  UpdatedAt,
  Model,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  DataType,
  Default,
  HasMany
} from "sequelize-typescript";
import Company from "./Company";

@Table
class Affiliate extends Model<Affiliate> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @ForeignKey(() => Company)
  @Column
  companyId: number;

  @BelongsTo(() => Company)
  company: Company;

  @Column({ unique: true })
  affiliateCode: string;

  @Column(DataType.DECIMAL(5, 2))
  commissionRate: number; // Porcentaje de comisión (ex: 10.00 = 10%)

  @Column(DataType.DECIMAL(10, 2))
  minWithdrawAmount: number; // Monto mínimo de retiro

  @Column(DataType.DECIMAL(10, 2))
  totalEarned: number;

  @Column(DataType.DECIMAL(10, 2))
  totalWithdrawn: number;

  @Default("active")
  @Column(DataType.ENUM("active", "inactive", "suspended"))
  status: string;

  // Las relaciones se definen en los modelos relacionados para evitar dependencias circulares.

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default Affiliate;
