import {
  Table,
  Column,
  CreatedAt,
  UpdatedAt,
  Model,
  DataType,
  BelongsTo,
  ForeignKey,
  Default
} from "sequelize-typescript";
import Contact from "./Contact";
import Ticket from "./Ticket";
import Whatsapp from "./Whatsapp";
import Company from "./Company";

@Table
class CallLog extends Model<CallLog> {
  @Column(DataType.STRING)
  callId: string;

  @Column(DataType.STRING)
  fromNumber: string;

  @Column(DataType.STRING)
  toNumber: string;

  @Default("offer")
  @Column(DataType.STRING)
  status: string; // offer | missed | rejected | accepted | ended

  @Default(false)
  @Column(DataType.BOOLEAN)
  isVideo: boolean;

  @Default(0)
  @Column(DataType.INTEGER)
  duration: number; // segundos

  @Column(DataType.DATE)
  startedAt: Date;

  @Column(DataType.DATE)
  endedAt: Date;

  // --- FKs ---
  @ForeignKey(() => Whatsapp)
  @Column(DataType.INTEGER)
  whatsappId: number;

  @BelongsTo(() => Whatsapp)
  whatsapp: Whatsapp;

  @ForeignKey(() => Ticket)
  @Column(DataType.INTEGER)
  ticketId: number;

  @BelongsTo(() => Ticket)
  ticket: Ticket;

  @ForeignKey(() => Contact)
  @Column(DataType.INTEGER)
  contactId: number;

  @BelongsTo(() => Contact)
  contact: Contact;

  @ForeignKey(() => Company)
  @Column(DataType.INTEGER)
  companyId: number;

  @BelongsTo(() => Company)
  company: Company;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default CallLog;