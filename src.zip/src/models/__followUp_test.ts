// Test file to verify FollowUp import
import FollowUp from "./FollowUp";

console.log("Modelo de seguimiento importado correctamente:", FollowUp);

export default FollowUp;
