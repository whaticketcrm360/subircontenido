import { Server as SocketIO } from "socket.io";
import { Server } from "http";
import AppError from "../errors/AppError";
import { instrument } from "@socket.io/admin-ui";
import User from "../models/User";
import logger from "../utils/logger";

let io: SocketIO;

export const initIO = (httpServer: Server): SocketIO => {
  io = new SocketIO(httpServer, {
    allowRequest: (req, callback) => {
      const isOriginValid = req.headers.origin;
      callback(null, isOriginValid === process.env.FRONTEND_URL);
    },
    cors: {
      origin: process.env.FRONTEND_URL
    }
  });

  // if (process.env.SOCKET_ADMIN && JSON.parse(process.env.SOCKET_ADMIN)) {
  //   User.findByPk(1).then(
  //     (adminUser) => {
  //       instrument(io, {
  //         auth: {
  //           type: "basic",
  //           username: adminUser.email,
  //           password: adminUser.passwordHash
  //         },
  //         mode: "development",
  //       });
  //     }
  //   );
  // }

  const workspaces = io.of(/^\/\w+$/);
  workspaces.on("connection", socket => {
    const rawUserId = socket.handshake.query?.userId as string | undefined;
    const parsedUserId =
      rawUserId && rawUserId !== "undefined" && rawUserId !== "null"
        ? Number(rawUserId)
        : null;

    // Si se pasa un ID de usuario válido, guárdelo en el socket
    if (parsedUserId && !Number.isNaN(parsedUserId)) {
      socket.data.userId = parsedUserId;
    } else {
      socket.data.userId = null;
    }

    let offlineTimeout: NodeJS.Timeout | null = null;

    // Cuando el cliente se desconecta
    socket.on("disconnect", async () => {
      const userId = socket.data.userId;
      console.log(`Client disconnected: ${socket.id}`);

      if (userId) {
        // Inicie el cronómetro de 60 segundos si es necesario.
        offlineTimeout = setTimeout(async () => {
          try {
            // Actualiza el estado del usuario a fuera de línea al instante
            await User.update({ online: false }, { where: { id: userId } });
            console.log(`Usuario ${userId} marcado como fuera de línea después de cerrar el navegador`);
          } catch (error) {
            console.error("Error al marcar al usuario como desconectado:", error);
          }
        }, 0);  // instantáneo para marcar como fuera de línea
      }
    });

    // Cuando el cliente se vuelve a conectar
    socket.on('reconnect', async () => {
      const userId = socket.data.userId;
      console.log(`Cliente reconectado: ${socket.id}`);

      if (offlineTimeout) {
        // Si el cliente se vuelve a conectar, borra el temporizador.
        clearTimeout(offlineTimeout);
        offlineTimeout = null;
      }

      if (userId) {
        try {
          // Actualizar estado a "en línea"
          await User.update({ online: true }, { where: { id: userId } });
          console.log(`Usuario ${userId} marcado como en línea`);
        } catch (error) {
          console.error("Error al marcar al usuario como en línea:", error);
        }
      }
    });

    // Otros eventos de conexión
    socket.on("joinChatBox", (ticketId: string) => {
      socket.join(ticketId);
    });

    socket.on("joinNotification", () => {
      socket.join("notification");
    });

    socket.on("joinTickets", (status: string) => {
      socket.join(status);
    });

    socket.on("joinTicketsLeave", (status: string) => {
      socket.leave(status);
    });

    socket.on("joinChatBoxLeave", (ticketId: string) => {
      socket.leave(ticketId);
    });

  });
  
  return io;
};

export const getIO = (): SocketIO => {
  if (!io) {
    throw new AppError("Socket IO no inicializado");
  }
  return io;
};
