import nodemailer from "nodemailer";

export interface MailData {
  to: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function SendMail(mailData: MailData) {
  const options: any = {
    host: process.env.MAIL_HOST,
    port: parseInt(process.env.MAIL_PORT || "465"),
    secure: true, // verdadero para 465, falso para otros puertos
    auth: {
      user: process.env.MAIL_USER,
      pass: process.env.MAIL_PASS
    }
  };

  const transporter = nodemailer.createTransport(options);

  // enviar correo con objeto de transporte definido
  let info = await transporter.sendMail({
    from: process.env.MAIL_FROM, // dirección del remitente
    to: mailData.to, // lista de receptores
    subject: mailData.subject, // Línea de asunto
    text: mailData.text, // cuerpo de texto plano
    html: mailData.html || mailData.text // cuerpo html
  });

  console.log("Message sent: %s", info.messageId);
  // Mensaje enviado: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

  // La vista previa solo está disponible cuando se envía a través de una cuenta Ethereal
  console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  // URL de vista previa: https://ethereal.email/message/WaQKMgKddxQDoou...
}
