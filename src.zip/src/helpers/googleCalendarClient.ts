import { google } from "googleapis";

const CLIENT_ID = process.env.GOOGLE_CLIENT_ID as string;
const CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET as string;
const REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI as string;

export const createOAuth2Client = () => {
  const oauth2Client = new google.auth.OAuth2(
    CLIENT_ID,
    CLIENT_SECRET,
    REDIRECT_URI
  );

  return oauth2Client;
};

export const getGoogleAuthUrl = (scopes: string[], state?: string) => {
  const oauth2Client = createOAuth2Client();

  const url = oauth2Client.generateAuthUrl({
    access_type: "offline",
    scope: scopes,
    prompt: "consent",
    state
  });

  return url;
};

export const getTokensFromCode = async (code: string) => {
  const oauth2Client = createOAuth2Client();

  const { tokens } = await oauth2Client.getToken(code);

  return tokens;
};

export const buildCalendarClient = (tokens: any) => {
  const oauth2Client = createOAuth2Client();
  oauth2Client.setCredentials(tokens);

  const calendar = google.calendar({ version: "v3", auth: oauth2Client });

  return calendar;
};

export const createGoogleCalendarEvent = async (
  accessToken: string,
  refreshToken: string | null = null,
  eventData: any,
  calendarId: string = "primary"
) => {
  try {
    const oauth2Client = createOAuth2Client();
    
    // Configurar credenciales con tokens de acceso y actualización
    const credentials: any = { access_token: accessToken };
    if (refreshToken) {
      credentials.refresh_token = refreshToken;
    }
    
    oauth2Client.setCredentials(credentials);

    // Configure la actualización automática si tiene un token de actualización
    if (refreshToken) {
      oauth2Client.on('tokens', (tokens) => {
        if (tokens.refresh_token) {
          // Aquí puedes guardar el nuevo token de actualización en el banco.
          console.log("DEBUG - Nuevos tokens recibidos:", tokens);
        }
      });
    }

    const calendar = google.calendar({ version: "v3", auth: oauth2Client });

    const event = await calendar.events.insert({
      calendarId,
      requestBody: eventData
    });

    return event.data;
  } catch (error: any) {
    console.error("Error al crear evento en Google Calendar:", error);
    
    // Si se trata de un error de token caducado, intente actualizar
    if (error.code === 401 && refreshToken) {
      try {
        console.log("DEBUG - Intentando actualizar el token...");
        const oauth2Client = createOAuth2Client();
        oauth2Client.setCredentials({ refresh_token: refreshToken });
        
        const { credentials } = await oauth2Client.refreshAccessToken();
        
        // Vuelve a intentarlo con el nuevo token.
        return await createGoogleCalendarEvent(
          credentials.access_token!,
          refreshToken,
          eventData,
          calendarId
        );
      } catch (refreshError) {
        console.error("ERROR - Error al actualizar el token:", refreshError);
        throw refreshError;
      }
    }
    
    throw error;
  }
};

export const updateGoogleCalendarEvent = async (
  accessToken: string,
  refreshToken: string | null = null,
  eventId: string,
  eventData: any,
  calendarId: string = "primary"
) => {
  try {
    const oauth2Client = createOAuth2Client();
    
    // Cconfigurar credenciales con tokens de acceso y actualización
    const credentials: any = { access_token: accessToken };
    if (refreshToken) {
      credentials.refresh_token = refreshToken;
    }
    
    oauth2Client.setCredentials(credentials);

    const calendar = google.calendar({ version: "v3", auth: oauth2Client });

    const event = await calendar.events.update({
      calendarId,
      eventId,
      requestBody: eventData
    });

    return event.data;
  } catch (error: any) {
    console.error("Error al actualizar el evento en Google Calendar:", error);
    
    // Si se trata de un error de token caducado, intente actualizar
    if (error.code === 401 && refreshToken) {
      try {
        console.log("DEBUG - Intentando actualizar el token para actualizarlo...");
        const oauth2Client = createOAuth2Client();
        oauth2Client.setCredentials({ refresh_token: refreshToken });
        
        const { credentials } = await oauth2Client.refreshAccessToken();
        
        // Vuelve a intentarlo con el nuevo token.
        return await updateGoogleCalendarEvent(
          credentials.access_token!,
          refreshToken,
          eventId,
          eventData,
          calendarId
        );
      } catch (refreshError) {
        console.error("ERROR - Error de actualización del token para la actualización:", refreshError);
        throw refreshError;
      }
    }
    
    throw error;
  }
};

export const deleteGoogleCalendarEvent = async (
  accessToken: string,
  refreshToken: string | null = null,
  eventId: string,
  calendarId: string = "primary"
) => {
  try {
    const oauth2Client = createOAuth2Client();
    
    // Configurar credenciales con tokens de acceso y actualización
    const credentials: any = { access_token: accessToken };
    if (refreshToken) {
      credentials.refresh_token = refreshToken;
    }
    
    oauth2Client.setCredentials(credentials);

    const calendar = google.calendar({ version: "v3", auth: oauth2Client });

    await calendar.events.delete({
      calendarId,
      eventId
    });

    return true;
  } catch (error: any) {
    console.error("Error al eliminar evento en Google Calendar:", error);
    
    // Si se trata de un error de token caducado, intente actualizar
    if (error.code === 401 && refreshToken) {
      try {
        console.log("DEBUG - Intentando actualizar el token para eliminarlo...");
        const oauth2Client = createOAuth2Client();
        oauth2Client.setCredentials({ refresh_token: refreshToken });
        
        const { credentials } = await oauth2Client.refreshAccessToken();
        
        // Vuelve a intentarlo con el nuevo token.
        return await deleteGoogleCalendarEvent(
          credentials.access_token!,
          refreshToken,
          eventId,
          calendarId
        );
      } catch (refreshError) {
        console.error("ERROR - Error al actualizar el token para eliminarlo:", refreshError);
        throw refreshError;
      }
    }
    
    throw error;
  }
};
