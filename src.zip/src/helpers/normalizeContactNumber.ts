const DIGIT_REGEX = /\D/g;

const stripDigits = (value?: string | null): string => {
  if (!value) return "";
  return value.replace(DIGIT_REGEX, "");
};

// Detecta si se trata de un LID (ID vinculado) de la API de WhatsApp Business
export const isLidNumber = (digits: string): boolean => {
  if (!digits) return false;
  // Los LID comienzan con 120 y tienen 15 o más dígitos
  if (digits.startsWith("120") && digits.length >= 15) {
    return true;
  }
  // También puede ser un WAID que comience con otros patrones y tenga más de 15 dígitos
  if (digits.length > 15) {
    return true;
  }
  return false;
};

// Normaliza números globales (solo dígitos, sin validar país específico)
export const normalizePhoneNumber = (value?: string | null): string => {
  let digits = stripDigits(value);

  if (!digits) {
    return "";
  }

  // Ignorar LID/WAID
  if (isLidNumber(digits)) {
    console.log(`[normalizePhoneNumber] LID/WAID detectado, ignorando: ${digits}`);
    return "";
  }

  // No forzar ningún prefijo de país
  return digits; // devuelve solo los dígitos limpios, cualquier longitud
};

const extractDigitsFromJid = (jid?: string | null): string => {
  if (!jid) return "";
  return stripDigits(jid);
};

const getCandidateNumbers = (candidates: Array<string | null | undefined>): string[] =>
  candidates
    .map(extractDigitsFromJid)
    .filter(digits => !!digits);

export const resolveContactNumber = ({
  rawNumber,
  remoteJid,
  remoteJidAlt,
  isGroup = false
}: {
  rawNumber?: string | null;
  remoteJid?: string | null;
  remoteJidAlt?: string | null;
  isGroup?: boolean;
}): string => {
  const rawCandidates = getCandidateNumbers([remoteJidAlt, remoteJid, rawNumber]);
  
  // Para grupos, usar primer candidato como ID
  if (isGroup && rawCandidates.length > 0) {
    const groupId = rawCandidates[0];
    console.log(`[resolveContactNumber - GRUPO] Usando ID de grupo: ${groupId}`);
    return groupId;
  }
  
  for (const digits of rawCandidates) {
    const normalized = normalizePhoneNumber(digits);
    if (normalized) {
      return normalized;
    }
  }

  return "";
};

export const buildRemoteJidFromNumber = (number: string, isGroup = false): string => {
  if (!number) return "";
  return isGroup ? `${number}@g.us` : `${number}@s.whatsapp.net`;
};

export const sanitizeRemoteJid = (
  remoteJid?: string | null,
  number?: string | null,
  isGroup = false
): string => {
  if (number) {
    const normalized = normalizePhoneNumber(number);
    if (normalized) {
      return buildRemoteJidFromNumber(normalized, isGroup);
    }
  }

  return "";
};