import { proto, WASocket } from "@whiskeysockets/baileys";
import cacheLayer from "../libs/cache";
import { getIO } from "../libs/socket";
import Message from "../models/Message";
import Ticket from "../models/Ticket";
import logger from "../utils/logger";
import GetTicketWbot from "./GetTicketWbot";
import ShowWhatsAppService from "../services/WhatsappService/ShowWhatsAppService";

const SetTicketMessagesAsRead = async (ticket: Ticket): Promise<void> => {

  if (ticket.whatsappId) {
    // console.log("CONFIGURAR MENSAJES COMO LEÍDOS", ticket.whatsappId)
    const whatsapp = await ShowWhatsAppService(
      ticket.whatsappId,


      ticket.companyId
    );

    if (["open", "group"].includes(ticket.status) && whatsapp && whatsapp.status === 'CONNECTED' && ticket.unreadMessages > 0) {
      try {
        const wbot = await GetTicketWbot(ticket);
        // En Baileys tenemos que marcar cada mensaje como leído
        // no todo el chat como se hace en el legado
        const getJsonMessage = await Message.findAll({
          where: {
            ticketId: ticket.id,
            fromMe: false,
            read: false
          },
          order: [["createdAt", "DESC"]]
        });

        if (getJsonMessage.length > 0) {

          getJsonMessage.forEach(async message => {
            const msg: proto.IWebMessageInfo = JSON.parse(message.dataJson);
            if (msg.key && msg.key.fromMe === false && !ticket.isBot && (ticket.userId || ticket.isGroup)) {

              await wbot.readMessages([msg.key])
            }
          });
        }

        await Message.update(
          { read: true },
          {
            where: {
              ticketId: ticket.id,
              read: false
            }
          }
        );

        await ticket.update({ unreadMessages: 0 });
        await cacheLayer.set(`contacts:${ticket.contactId}:unreads`, "0");

        const io = getIO();

        io.of(ticket.companyId.toString())
          // .to(ticket.status).to("notification")
          .emit(`company-${ticket.companyId}-ticket`, {
            action: "updateUnread",
            ticketId: ticket.id
          });

      } catch (err) {
        logger.warn(
          `No se pudieron marcar los mensajes como leídos. ¿Quizás la sesión de WhatsApp se desconectó? Errar: ${err}`
        );
      }

    }
  }

};

export default SetTicketMessagesAsRead;