import { Request, Response } from "express";
import { getIO } from "../libs/socket";
import Message from "../models/Message";
import Ticket from "../models/Ticket";
import User from "../models/User";
import UserDevice from "../models/UserDevice";
import Contact from "../models/Contact";

// Plantilla para los dispositivos móviles de los usuarios.
interface UserDeviceData {
  userId: number;
  deviceToken: string;
  platform: 'ios' | 'android';
  createdAt: Date;
  updatedAt: Date;
}

// Servicio de registro de dispositivo móvil para notificaciones.
export const registerDevice = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { deviceToken, platform } = req.body;
    const userId = req.user.id;

    if (!deviceToken || !platform) {
      throw new Error("ERR_MISSING_DEVICE_INFO");
    }

    // Comprueba si ya hay un dispositivo registrado
    const existingDevice = await UserDevice.findOne({
      where: { userId, deviceToken }
    });

    if (existingDevice) {
      // Actualizar dispositivo existente
      await existingDevice.update({ platform, updatedAt: new Date() });
    } else {
      // Crear nuevo registro de dispositivo
      await UserDevice.create({
        userId,
        deviceToken,
        platform,
        createdAt: new Date(),
        updatedAt: new Date()
      });
    }

    return res.status(200).json({ success: true, message: "Dispositivo registrado exitosamente" });
  } catch (error) {
    console.error("Error al registrar el dispositivo:", error);
    return res.status(400).json({ success: false, error: error.message });
  }
};

// Servicio para retirar dispositivo
export const unregisterDevice = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { deviceToken } = req.body;
    const userId = req.user.id;

    await UserDevice.destroy({
      where: { userId, deviceToken }
    });

    return res.status(200).json({ success: true, message: "Dispositivo cancelado exitosamente" });
  } catch (error) {
    console.error("Error al cancelar el registro del dispositivo:", error);
    return res.status(400).json({ success: false, error: error.message });
  }
};

// Función para enviar notificaciones push a dispositivos móviles
export const sendPushNotification = async (
  userId: number,
  title: string,
  body: string,
  data?: any
): Promise<void> => {
  try {
    // Buscar dispositivos de usuario
    const devices = await UserDevice.findAll({
      where: { userId }
    });

    if (devices.length === 0) {
      return;
    }

    // Agrupar dispositivos por plataforma
    const androidDevices = devices.filter(d => d.platform === 'android').map(d => d.deviceToken);
    const iosDevices = devices.filter(d => d.platform === 'ios').map(d => d.deviceToken);

    // Enviar notificaciones (implementar con Firebase Cloud Messaging o similar)
    if (androidDevices.length > 0) {
      // Implementar envíos para Android
      console.log(`Envío de notificaciones push a dispositivos Android: ${androidDevices.join(', ')}`);
    }

    if (iosDevices.length > 0) {
      // Implementar envíos para iOS
      console.log(`Envío de notificaciones push a dispositivos iOS: ${iosDevices.join(', ')}`);
    }

  } catch (error) {
    console.error("Error al enviar notificación push:", error);
  }
};

// Middleware para enviar notificaciones cuando llega un nuevo mensaje
export const notifyNewMessage = async (message: any): Promise<void> => {
  try {
    // Buscar ticket y usuario asociado
    const ticket = await Ticket.findByPk(message.ticketId, {
      include: [
        { model: User, as: 'user' },
        { model: Contact, as: 'contact' }
      ]
    });

    if (!ticket || !ticket.user) {
      return;
    }

    // Enviar notificación push
    await sendPushNotification(
      ticket.user.id,
      `Nuevo mensaje de ${ticket.contact?.name || 'Contacto'}`,
      message.body || 'Nuevo mensaje',
      {
        ticketId: ticket.id,
        messageId: message.id,
        contactId: ticket.contactId
      }
    );

    // Emitir evento WebSocket para web
    const io = getIO();
    io.of(ticket.companyId.toString()).emit(`company-${ticket.companyId}-message`, {
      action: "create",
      message,
      ticket: {
        id: ticket.id,
        userId: ticket.userId,
        contactId: ticket.contactId
      }
    });

  } catch (error) {
    console.error("Error al notificar mensaje nuevo:", error);
  }
};
