import { Request, Response } from "express";
import CreateUserScheduleService from "../services/UserScheduleServices/CreateUserScheduleService";
import ListUserSchedulesService from "../services/UserScheduleServices/ListUserSchedulesService";
import ShowUserScheduleService from "../services/UserScheduleServices/ShowUserScheduleService";
import UpdateUserScheduleService from "../services/UserScheduleServices/UpdateUserScheduleService";
import DeleteUserScheduleService from "../services/UserScheduleServices/DeleteUserScheduleService";

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { companyId, id: userId, profile } = req.user;
  const userType = (req.user as any).userType || "";
  const { searchParam, active, pageNumber } = req.query as Record<string, string>;

  const result = await ListUserSchedulesService({
    companyId: Number(companyId),
    userId: Number(userId),
    profile,
    userType,
    searchParam,
    active,
    pageNumber
  });

  return res.json(result);
};

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { id } = req.params;

  const schedule = await ShowUserScheduleService(id, Number(companyId));

  return res.json(schedule);
};

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { companyId, id: currentUserId, profile } = req.user;
  const userType = (req.user as any).userType || "";
  const { name, description, active, userId } = req.body;

  // Si no eres administrador, solo puedes crear un horario para ti
  let targetUserId = userId;
  if (profile !== "admin" && userType !== "admin") {
    targetUserId = Number(currentUserId);
  }

  const schedule = await CreateUserScheduleService({
    name,
    description,
    active,
    userId: targetUserId,
    companyId: Number(companyId)
  });

  return res.status(201).json(schedule);
};

export const update = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { id } = req.params;
  const { name, description, active } = req.body;

  const schedule = await UpdateUserScheduleService({
    id,
    name,
    description,
    active,
    companyId: Number(companyId)
  });

  return res.json(schedule);
};

export const remove = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { id } = req.params;

  await DeleteUserScheduleService(id, Number(companyId));

  return res.status(204).send();
};

export const linkGoogleIntegration = async (req: Request, res: Response): Promise<Response> => {
  const { companyId, id: userId } = req.user;
  const { id: scheduleId } = req.params;
  const { userGoogleCalendarIntegrationId } = req.body;

  try {
    // Compruebe si la integración pertenece al usuario que inició sesión
    const UserGoogleCalendarIntegration = require("../models/UserGoogleCalendarIntegration").default;
    const UserSchedule = require("../models/UserSchedule").default;
    
    const integration = await UserGoogleCalendarIntegration.findOne({
      where: { 
        id: userGoogleCalendarIntegrationId,
        userId: userId
      }
    });

    if (!integration) {
      return res.status(404).json({ error: "Integración no encontrada o no pertenece al usuario" });
    }

    // Comprobar si el calendario pertenece al usuario o si es administrador
    const schedule = await UserSchedule.findOne({
      where: { id: scheduleId, companyId: companyId }
    });

    if (!schedule) {
      return res.status(404).json({ error: "Calendario no encontrado" });
    }

    // Vincular la integración a la agenda
    await schedule.update({ userGoogleCalendarIntegrationId });

    return res.json({ 
      message: "Agenda vinculada a Google Calendar con éxito",
      schedule: schedule
    });
  } catch (error) {
    console.error("Error al vincular la integración de Google Calendar:", error);
    return res.status(500).json({ error: "Error al vincular la integración" });
  }
};
