import { Request, Response } from "express";
import IaWorkflow from "../models/IaWorkflow";
import Prompt from "../models/Prompt";
import ListIaWorkflowsByPromptService from "../services/IaWorkflowService/ListIaWorkflowsByPromptService";
import logger from "../utils/logger";

interface IaWorkflowData {
  name: string;
  description?: string;
  orchestratorPromptId: number;
  agents: Array<{
    agentPromptId: number;
    alias: string;
  }>;
  flowData?: any;
}

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { orchestratorPromptId } = req.query;
  logger.info({
    message: "[IaWorkflowController] index called",
    companyId,
    orchestratorPromptId
  });

  try {
    if (orchestratorPromptId) {
      // Enumerar flujos de trabajo por mensaje del orquestador
      const workflows = await ListIaWorkflowsByPromptService({
        companyId,
        orchestratorPromptId: Number(orchestratorPromptId)
      });
      return res.json(workflows);
    } else {
      // Enumere todos los flujos de trabajo de la empresa (agrupados por orquestador)
      const workflows = await IaWorkflow.findAll({
        where: { companyId },
        order: [["createdAt", "DESC"]]
      });

      // Buscar nombres de mensajes del orquestador
      const orchestratorIds = [...new Set(workflows.map(w => w.orchestratorPromptId))];
      const orchestratorPrompts = await Prompt.findAll({
        where: { id: orchestratorIds },
        attributes: ['id', 'name']
      });

      // Agrupar por orquestador y crear estructura para el listado
      const groupedWorkflows = workflows.reduce((acc: any, workflow: any) => {
        const key = workflow.orchestratorPromptId;
        if (!acc[key]) {
          const orchestratorPrompt = orchestratorPrompts.find(p => p.id === workflow.orchestratorPromptId);
          acc[key] = {
            id: workflow.orchestratorPromptId,
            orchestratorPromptId: workflow.orchestratorPromptId,
            name: orchestratorPrompt ? `Workflow - ${orchestratorPrompt.name}` : `Workflow - orquestador ${workflow.orchestratorPromptId}`,
            description: `Workflow multi-agente con IA orquestadora`,
            agents: [],
            createdAt: workflow.createdAt,
            updatedAt: workflow.updatedAt
          };
        }
        acc[key].agents.push({
          id: workflow.id,
          agentPromptId: workflow.agentPromptId,
          alias: workflow.alias,
          createdAt: workflow.createdAt,
          updatedAt: workflow.updatedAt
        });
        return acc;
      }, {});

      const workflowList = Object.values(groupedWorkflows).map((group: any) => ({
        ...group,
        connections: group.agents,
        agentCount: group.agents.length
      }));

      logger.info({
        message: "[IaWorkflowController] index returning grouped workflows",
        companyId,
        count: workflowList.length
      });
      return res.json(workflowList);
    }
  } catch (error) {
    logger.error({
      message: "[IaWorkflowController] Listado de errores workflows",
      error,
      companyId,
      orchestratorPromptId
    });
    return res.status(500).json({ error: "Error Interno del Servidor" });
  }
};

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { id } = req.params;
  logger.info({
    message: "[IaWorkflowController] show called",
    companyId,
    orchestratorPromptId: id
  });

  try {
    // Buscar todos los flujos de trabajo del orquestador
    const workflows = await IaWorkflow.findAll({
      where: { 
        companyId,
        orchestratorPromptId: id
      }
    });

    if (workflows.length === 0) {
      return res.status(404).json({ error: "Workflow extraviado" });
    }

    // Obtener el nombre del mensaje del orquestador para usarlo como nombre del flujo de trabajo
    const orchestratorPrompt = await Prompt.findByPk(id, {
      attributes: ['id', 'name']
    });

    const workflowData = {
      name: orchestratorPrompt ? `Workflow - ${orchestratorPrompt.name}` : `Workflow - orquestador ${id}`,
      description: `Workflow multi-agente con ${workflows.length} IA${workflows.length > 1 ? 's' : ''} especializado${workflows.length > 1 ? 's' : ''}`,
      orchestratorPromptId: Number(id),
      agents: workflows.map(w => ({
        id: w.id,
        agentPromptId: w.agentPromptId,
        alias: w.alias
      }))
    };

    logger.info({
      message: "[IaWorkflowController] mostrar regresando workflow",
      companyId,
      orchestratorPromptId: id,
      agents: workflowData.agents.length
    });
    return res.json(workflowData);
  } catch (error) {
    logger.error({
      message: "[IaWorkflowController] Error al mostrar workflow",
      error,
      companyId,
      orchestratorPromptId: id
    });
    return res.status(500).json({ error: "Error Interno del Servidor" });
  }
};

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const workflowData: IaWorkflowData = req.body;
  logger.info({
    message: "[IaWorkflowController] store called",
    companyId,
    workflowData
  });

  try {
    const { orchestratorPromptId, agents } = workflowData;

    if (!orchestratorPromptId || !agents || agents.length === 0) {
      return res.status(400).json({ 
        error: "orchestratorPromptId y los agentes son obligatorios" 
      });
    }

    // Eliminar flujos de trabajo existentes del Orchestrator
    await IaWorkflow.destroy({
      where: {
        companyId,
        orchestratorPromptId
      }
    });

    // Crear nuevos flujos de trabajo
    const createdWorkflows = [];
    for (const agent of agents) {
      const workflow = await IaWorkflow.create({
        companyId,
        orchestratorPromptId,
        agentPromptId: agent.agentPromptId,
        alias: agent.alias
      });
      createdWorkflows.push(workflow);
    }

    logger.info({
      message: "[IaWorkflowController] Workflow creado",
      companyId,
      orchestratorPromptId,
      agentsCreated: createdWorkflows.length
    });
    return res.status(201).json({
      message: "Workflow creado exitosamente",
      workflows: createdWorkflows
    });
  } catch (error) {
    logger.error({
      message: "[IaWorkflowController] Error al crear workflow",
      error,
      companyId,
      workflowData
    });
    return res.status(500).json({ error: "Error Interno del Servidor" });
  }
};

export const update = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { id } = req.params;
  const workflowData: IaWorkflowData = req.body;
  logger.info({
    message: "[IaWorkflowController] update called",
    companyId,
    orchestratorPromptId: id,
    workflowData
  });

  try {
    const { agents } = workflowData;

    if (!agents || agents.length === 0) {
      return res.status(400).json({ 
        error: "agentes es obligatorio" 
      });
    }

    // Eliminar flujos de trabajo existentes del Orchestrator
    await IaWorkflow.destroy({
      where: {
        companyId,
        orchestratorPromptId: id
      }
    });

    // Crear nuevos flujos de trabajo
    const updatedWorkflows = [];
    for (const agent of agents) {
      const workflow = await IaWorkflow.create({
        companyId,
        orchestratorPromptId: Number(id),
        agentPromptId: agent.agentPromptId,
        alias: agent.alias
      });
      updatedWorkflows.push(workflow);
    }

    logger.info({
      message: "[IaWorkflowController] Workflow updated",
      companyId,
      orchestratorPromptId: id,
      agentsUpdated: updatedWorkflows.length
    });
    return res.json({
      message: "Workflow actualizado exitosamente",
      workflows: updatedWorkflows
    });
  } catch (error) {
    logger.error({
      message: "[IaWorkflowController] Error al actualizar workflow",
      error,
      companyId,
      orchestratorPromptId: id,
      workflowData
    });
    return res.status(500).json({ error: "Error Interno del Servidor" });
  }
};

export const remove = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { id } = req.params;
  logger.info({
    message: "[IaWorkflowController] eliminar called",
    companyId,
    orchestratorPromptId: id
  });

  try {
    const deletedCount = await IaWorkflow.destroy({
      where: {
        companyId,
        orchestratorPromptId: id
      }
    });

    if (deletedCount === 0) {
      return res.status(404).json({ error: "Workflow extraviado" });
    }

    logger.info({
      message: "[IaWorkflowController] Workflow remoto",
      companyId,
      orchestratorPromptId: id,
      deletedCount
    });
    return res.json({ message: "Workflow eliminado exitosamente" });
  } catch (error) {
    logger.error({
      message: "[IaWorkflowController] Error al eliminar workflow",
      error,
      companyId,
      orchestratorPromptId: id
    });
    return res.status(500).json({ error: "Error Interno del Servidor" });
  }
};
