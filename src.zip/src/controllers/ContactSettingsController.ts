import { Request, Response } from "express";
import isAuth from "../middleware/isAuth";
import CompaniesSettings from "../models/CompaniesSettings";
import { getIO } from "../libs/socket";
import logger from "../utils/logger";
import AppError from "../errors/AppError";
import { GetContactStats, GetHighPotentialContacts } from "../services/ContactServices/ContactScoringService";
import { GetPhoneSavingStats, BatchSaveContactsToPhone } from "../services/ContactServices/ContactPhoneService";
import Contact from "../models/Contact";
import Whatsapp from "../models/Whatsapp";

export const index = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { companyId } = req.user;

    const settings = await CompaniesSettings.findOne({
      where: { companyId }
    });

    if (!settings) {
      // Crear configuraciones predeterminadas si no existe ninguna
      const defaultSettings = await CompaniesSettings.create({
        companyId,
        autoSaveContacts: "disabled",
        autoSaveContactsScore: 7,
        autoSaveContactsReason: "high_potential"
      });

      return res.status(200).json({
        autoSaveContacts: defaultSettings.autoSaveContacts,
        autoSaveContactsScore: defaultSettings.autoSaveContactsScore,
        autoSaveContactsReason: defaultSettings.autoSaveContactsReason
      });
    }

    return res.status(200).json({
      autoSaveContacts: settings.autoSaveContacts,
      autoSaveContactsScore: settings.autoSaveContactsScore,
      autoSaveContactsReason: settings.autoSaveContactsReason
    });

  } catch (error) {
    logger.error("Error al obtener la configuración de contacto:", error);
    throw new AppError("ERR_GET_CONTACT_SETTINGS", 500);
  }
};

export const update = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { companyId } = req.user;
    const {
      autoSaveContacts,
      autoSaveContactsScore,
      autoSaveContactsReason
    } = req.body;

    logger.info("=== UPDATE CONTACT SETTINGS START ===");
    logger.info("Request body:", {
      autoSaveContacts,
      autoSaveContactsScore,
      autoSaveContactsReason,
      companyId
    });

    // Validaciones
    if (autoSaveContacts && !["disabled", "enabled", "all", "important"].includes(autoSaveContacts)) {
      throw new AppError("Invalid autoSaveContacts value", 400);
    }

    if (autoSaveContactsScore && (autoSaveContactsScore < 0 || autoSaveContactsScore > 10)) {
      throw new AppError("autoSaveContactsScore must be between 0 and 10", 400);
    }

    if (autoSaveContactsReason && !["high_potential", "message_analysis", "business_hours"].includes(autoSaveContactsReason)) {
      throw new AppError("Invalid autoSaveContactsReason value", 400);
    }

    const settings = await CompaniesSettings.findOne({
      where: { companyId }
    });

    if (!settings) {
      // Crear si no existe
      const newSettings = await CompaniesSettings.create({
        companyId,
        autoSaveContacts: autoSaveContacts || "enabled",
        autoSaveContactsScore: autoSaveContactsScore || 7,
        autoSaveContactsReason: autoSaveContactsReason || "high_potential"
      });
    } else {
      // Actualizar si existe
      logger.info("Actualizar la configuración existente");
      await settings.update({
        autoSaveContacts: autoSaveContacts,
        autoSaveContactsScore: autoSaveContactsScore,
        autoSaveContactsReason: autoSaveContactsReason
      });
      logger.info("Configuraciones actualizadas en la base de datos.");
    }

    // Emitir evento para actualización en tiempo real
    const io = getIO();
    io.of(String(companyId)).emit(`company-${companyId}-contactSettings`, {
      action: "update",
      settings: {
        autoSaveContacts,
        autoSaveContactsScore,
        autoSaveContactsReason
      }
    });

    logger.info(`Configuración de contacto actualizada para la empresa ${companyId}`);

    // Devolver el objeto de configuración actualizado completo
    const updatedSettings = await CompaniesSettings.findOne({
      where: { companyId }
    });
    
    logger.info("Configuraciones actualizadas de la base de datos:", updatedSettings?.get());

    return res.status(200).json({
      message: "Configuración actualizada exitosamente",
      settings: updatedSettings
    });

  } catch (error) {
    logger.error("Error al actualizar la configuración de contacto:", error);
    if (error instanceof AppError) {
      throw error;
    }
    throw new AppError("ERR_UPDATE_CONTACT_SETTINGS", 500);
  }
};

export const getStats = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { companyId } = req.user;

    // Buscar configuración de la empresa
    const settings = await CompaniesSettings.findOne({
      where: { companyId }
    });

    // Buscar estadísticas de contactos
    const contactStats = await GetContactStats(companyId);

    // Busca estadísticas de guardado en tu celular
    const phoneStats = await GetPhoneSavingStats(companyId);

    // Búsqueda de contactos de alto potencial
    const highPotentialContacts = await GetHighPotentialContacts(companyId, 10);

    return res.status(200).json({
      settings: {
        autoSaveContacts: settings?.autoSaveContacts || "disabled",
        autoSaveContactsScore: settings?.autoSaveContactsScore || 7,
        autoSaveContactsReason: settings?.autoSaveContactsReason || "high_potential"
      },
      contactStats,
      phoneStats,
      highPotentialContacts: highPotentialContacts.map(contact => ({
        id: contact.id,
        name: contact.name,
        number: contact.number,
        potentialScore: contact.potentialScore,
        isPotential: contact.isPotential,
        savedToPhone: contact.savedToPhone,
        createdAt: contact.createdAt
      }))
    });

  } catch (error) {
    logger.error("Error al obtener estadísticas de contacto:", error);
    throw new AppError("ERR_GET_CONTACT_STATS", 500);
  }
};

export const batchSaveToPhone = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { companyId } = req.user;
    const { contactIds } = req.body;

    if (!contactIds || !Array.isArray(contactIds)) {
      throw new AppError("contactIds debe ser un array", 400);
    }

    if (contactIds.length === 0) {
      throw new AppError("contactIds cno puede estar vacío", 400);
    }

    if (contactIds.length > 100) {
      throw new AppError("Máximo 100 contactos por lote", 400);
    }

    // Buscar contactos
    const contacts = await Contact.findAll({
      where: {
        id: contactIds,
        companyId,
        savedToPhone: false // Sólo contactos no guardados
      }
    });

    if (contacts.length === 0) {
      return res.status(200).json({
        message: "No hay contactos para guardar (todos ya guardados o no encontrados)",
        success: 0,
        failed: 0
      });
    }

    // Obtenga el ID de WhatsApp predeterminado utilizando el método predeterminado del sistema
    const defaultWhatsapp = await Whatsapp.findOne({
      where: {
        companyId,
        isDefault: true
      }
    });

    if (!defaultWhatsapp) {
      throw new AppError("No se encontró ninguna conexión predeterminada de WhatsApp", 400);
    }

    const whatsappId = defaultWhatsapp.id;

    // Guardar contactos por lotes
    const result = await BatchSaveContactsToPhone(contacts, whatsappId, companyId);

    logger.info(`Guardado por lotes completado para la empresa ${companyId}: ${result.success} éxito, ${result.failed} fallido`);

    return res.status(200).json({
      message: "Guardado por lotes completado",
      success: result.success,
      failed: result.failed,
      total: contacts.length
    });

  } catch (error) {
    logger.error("Error al guardar por lotes en el teléfono:", error);
    if (error instanceof AppError) {
      throw error;
    }
    throw new AppError("ERR_BATCH_SAVE_TO_PHONE", 500);
  }
};

export const testConfiguration = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { companyId } = req.user;
    const { testMessage } = req.body;

    if (!testMessage) {
      throw new AppError("testMessage se requiere", 400);
    }

    // Importar CalculatePotentialScore para pruebas
    const { CalculatePotentialScore } = await import("../services/ContactServices/ContactScoringService");
    
    const score = CalculatePotentialScore(testMessage);
    const isPotential = score >= 5;

    // Buscar configuración actual
    const settings = await CompaniesSettings.findOne({
      where: { companyId }
    });

    const wouldSave = settings?.autoSaveContacts === "enabled" && score >= (settings?.autoSaveContactsScore || 7);

    return res.status(200).json({
      testMessage,
      score,
      isPotential,
      wouldSave,
      currentSettings: {
        autoSaveContacts: settings?.autoSaveContacts || "enabled",
        autoSaveContactsScore: settings?.autoSaveContactsScore || 7,
        autoSaveContactsReason: settings?.autoSaveContactsReason || "high_potential"
      }
    });

  } catch (error) {
    logger.error("Configuración de prueba de errores:", error);
    if (error instanceof AppError) {
      throw error;
    }
    throw new AppError("ERR_TEST_CONFIGURATION", 500);
  }
};

export const resetSettings = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { companyId } = req.user;

    const settings = await CompaniesSettings.findOne({
      where: { companyId }
    });

    if (!settings) {
      throw new AppError("Configuraciones no encontradas", 404);
    }

    // Restablecer los valores predeterminados
    await settings.update({
      autoSaveContacts: "enabled",
      autoSaveContactsScore: 7,
      autoSaveContactsReason: "high_potential"
    });

    // Emitir evento de actualización
    const io = getIO();
    io.of(String(companyId)).emit(`company-${companyId}-contactSettings`, {
      action: "reset",
      settings: {
        autoSaveContacts: "enabled",
        autoSaveContactsScore: 7,
        autoSaveContactsReason: "high_potential"
      }
    });

    logger.info(`Restablecer la configuración de contacto para la empresa ${companyId}`);

    return res.status(200).json({
      message: "La configuración se restablece a los valores predeterminados",
      autoSaveContacts: "enabled",
      autoSaveContactsScore: 7,
      autoSaveContactsReason: "high_potential"
    });

  } catch (error) {
    logger.error("Error al restablecer la configuración de contacto:", error);
    if (error instanceof AppError) {
      throw error;
    }
    throw new AppError("ERR_RESET_CONTACT_SETTINGS", 500);
  }
};
