// Este archivo ha sido deshabilitado: la imagen de carga ahora se guarda como configuración a través de /settings-whitelabel/logo
export {};
