import { Request, Response } from "express";
import AppError from "../errors/AppError";
import TicketTag from "../models/TicketTag";
import Tag from "../models/Tag";
import Ticket from "../models/Ticket";
import Contact from "../models/Contact";
import { getIO } from "../libs/socket";

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { ticketId, tagId } = req.params;

  try {
    // Garantiza que el ticket tenga como máximo UNA etiqueta Kanban
    // @ts-ignore - Los métodos estáticos de Sequelize se resuelven en tiempo de ejecución.
    const tag = await Tag.findByPk(tagId);

    if (!tag) {
      throw new AppError("ERR_NO_TAG_FOUND", 404);
    }

    if (tag.kanban === 1) {
      // Buscar todas las etiquetas ya vinculadas al ticket
      // @ts-ignore - Los métodos estáticos de Sequelize se resuelven en tiempo de ejecución.
      const existingTicketTags = await TicketTag.findAll({ where: { ticketId } });
      const existingTagIds = existingTicketTags.map(tt => tt.tagId);

      if (existingTagIds.length) {
        // Filtra solo etiquetas con kanban = 1 entre las ya vinculadas
        // @ts-ignore - Los métodos estáticos de Sequelize se resuelven en tiempo de ejecución.
        const existingKanbanTags = await Tag.findAll({
          where: {
            id: existingTagIds,
            kanban: 1,
          },
        });

        const existingKanbanTagIds = existingKanbanTags
          .map(t => t.id)
          // evita eliminar la etiqueta que se agrega
          .filter(id => String(id) !== String(tagId));

        if (existingKanbanTagIds.length) {
          // @ts-ignore: Sequelize acepta matriz en donde.tagId
          await TicketTag.destroy({ where: { ticketId, tagId: existingKanbanTagIds } });
        }
      }
    }

    // @ts-ignore: Método dinámico de secuenciación.
    const ticketTag = await TicketTag.create({ ticketId, tagId });

    // Vuelva a cargar el ticket con etiquetas y contact.tags para reflejarlo en la interfaz
    const ticket = await Ticket.findByPk(ticketId, {
      include: [
        {
          model: Contact,
          as: "contact",
          attributes: ["id", "name", "number", "email", "profilePicUrl", "acceptAudioMessage", "active", "urlPicture", "companyId"],
          include: ["extraInfo", "tags"],
        },
        {
          model: Tag,
          as: "tags",
          attributes: ["id", "name", "color"],
        },
      ],
    });

    if (ticket) {
      const io = getIO();
      io.of(String(ticket.companyId)).emit(`company-${ticket.companyId}-ticket`, {
        action: "update",
        ticket,
      });
    }

    return res.status(201).json(ticketTag);
  } catch (error: any) {
    console.error("[TicketTagController.store] Error al almacenar la etiqueta del ticket", {
      ticketId,
      tagId,
      error: error?.message || error,
    });
    return res.status(500).json({
      error: "No se pudo almacenar la etiqueta del boleto.",
      details: error?.message || String(error),
    });
  }
};

export const remove = async (req: Request, res: Response): Promise<Response> => {
  const { ticketId } = req.params;

  try {
    // Eliminación manual de TODAS las etiquetas vinculadas al ticket (incluido Kanban)
    // @ts-ignore - Los métodos estáticos de Sequelize se resuelven en tiempo de ejecución.
    await TicketTag.destroy({ where: { ticketId } });

    // Vuelva a cargar el ticket para reflejar la eliminación de la etiqueta
    const ticket = await Ticket.findByPk(ticketId, {
      include: [
        {
          model: Contact,
          as: "contact",
          attributes: ["id", "name", "number", "email", "profilePicUrl", "acceptAudioMessage", "active", "urlPicture", "companyId"],
          include: ["extraInfo", "tags"],
        },
        {
          model: Tag,
          as: "tags",
          attributes: ["id", "name", "color"],
        },
      ],
    });

    if (ticket) {
      const io = getIO();
      io.of(String(ticket.companyId)).emit(`company-${ticket.companyId}-ticket`, {
        action: "update",
        ticket,
      });
    }

    return res.status(200).json({ message: "Las etiquetas de los tickets se eliminaron correctamente." });
  } catch (error: any) {
    console.error("[TicketTagController.remove] Error al eliminar etiquetas de ticket", {
      ticketId,
      error: error?.message || error,
    });
    return res.status(500).json({
      error: "No se pudieron eliminar las etiquetas de los tickets.",
      details: error?.message || String(error),
    });
  }
};