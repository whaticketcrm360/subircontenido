import { Request, Response } from "express";
import ListCrmClientsService from "../services/CrmClientService/ListCrmClientsService";
import CreateCrmClientService from "../services/CrmClientService/CreateCrmClientService";
import ShowCrmClientService from "../services/CrmClientService/ShowCrmClientService";
import UpdateCrmClientService from "../services/CrmClientService/UpdateCrmClientService";
import DeleteCrmClientService from "../services/CrmClientService/DeleteCrmClientService";

export const index = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId, id: userId } = req.user;
  const userType = (req.user as any).userType;
  const {
    searchParam,
    status,
    type,
    ownerUserId,
    pageNumber,
    limit
  } = req.query as any;

  // **COMPLETA LA SOLICITUD DE INFORMACIÓN DEL USUARIO**
  const requestingUserId = Number(userId);
  const requestingUserType = userType?.toLowerCase();

  // Si eres profesional, filtra sólo los clientes vinculados a ti
  const isProfessional = requestingUserType === "professional";
  const filterOwnerUserId = isProfessional ? requestingUserId : (ownerUserId && ownerUserId !== "undefined" ? Number(ownerUserId) : undefined);

  const result = await ListCrmClientsService({
    companyId,
    searchParam,
    status,
    type,
    ownerUserId: filterOwnerUserId,
    requestingUserId,
    requestingUserType,
    pageNumber: pageNumber ? Number(pageNumber) : undefined,
    limit: limit ? Number(limit) : undefined
  });

  return res.json(result);
};

export const store = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId } = req.user;
  const data = req.body;

  const client = await CreateCrmClientService({
    ...data,
    companyId,
    // **USUARIO CREADOR DEL ENLACE COMO RESPONSABLE**
    createdByUserId: req.user.id
  });

  return res.status(201).json(client);
};

export const show = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId } = req.user;
  const { clientId } = req.params;

  const clientIdNum = Number(clientId);
  
  if (!clientId || isNaN(clientIdNum)) {
    return res.status(400).json({ error: "ID no válida" });
  }

  const client = await ShowCrmClientService({
    id: clientIdNum,
    companyId
  });

  // Transforme los propietarios en OwnerUserIds para compatibilidad con el frontend
  const clientData = client.toJSON() as any;
  if (clientData.owners && Array.isArray(clientData.owners)) {
    clientData.ownerUserIds = clientData.owners.map((owner: any) => owner.id);
  }

  return res.json(clientData);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId } = req.user;
  const { clientId } = req.params;
  const clientData = req.body;

  const clientIdNum = Number(clientId);
  
  if (!clientId || isNaN(clientIdNum)) {
    return res.status(400).json({ error: "ID no válida" });
  }

  const client = await UpdateCrmClientService({
    id: clientIdNum,
    companyId,
    ...clientData
  });

  return res.json(client);
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId } = req.user;
  const { clientId } = req.params;

  const clientIdNum = Number(clientId);
  
  if (!clientId || isNaN(clientIdNum)) {
    return res.status(400).json({ error: "ID no válida" });
  }

  await DeleteCrmClientService({
    id: clientIdNum,
    companyId
  });

  return res.status(204).send();
};

export const exportClients = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { clientIds } = req.body;

  console.log("📤 [EXPORT] Iniciar exportación de clientes seleccionados");
  console.log("📤 [EXPORT] Identificaciones seleccionadas:", clientIds);

  try {
    let clients;
    
    if (clientIds && clientIds.length > 0) {
      // Exportar solo clientes seleccionados
      const CrmClient = require("../models/CrmClient").default;
      const User = require("../models/User").default;
      
      clients = await CrmClient.findAll({
        where: {
          id: clientIds,
          companyId
        },
        include: [
          {
            model: User,
            as: "owners",
            attributes: ["id", "name", "email"],
            through: { attributes: [] }
          }
        ],
        order: [["updatedAt", "DESC"]]
      });
    } else {
      // Exportar todos (fallback)
      const result = await ListCrmClientsService({
        companyId,
        pageNumber: 1,
        limit: 10000
      });
      clients = result.clients;
    }

    console.log("📤 [EXPORT] Clientes encontrados:", clients.length);

    // **GENERAR CSV CON TODOS LOS CAMPOS**
    const csvHeaders = [
      'ID',
      'Nombre',
      'nombre de empresa',
      'Tipo',
      'Documento',
      'E-mail',
      'Teléfono',
      'DIRECCIÓN',
      'Número',
      'Vecindario',
      'Ciudad',
      'Estado',
      'CEP',
      'Estado',
      'Identificación responsable',
      'Nombre del responsable',
      'Fecha de registro',
      'Última actualización',
      'Notas'
    ];

    const csvRows = clients.map(client => [
      client.id || '',
      `"${(client.name || '').replace(/"/g, '""')}"`,
      `"${(client.companyName || '').replace(/"/g, '""')}"`,
      client.type || '',
      `"${(client.document || '').replace(/"/g, '""')}"`,
      `"${(client.email || '').replace(/"/g, '""')}"`,
      `"${(client.phone || '').replace(/"/g, '""')}"`,
      `"${(client.address || '').replace(/"/g, '""')}"`,
      `"${(client.number || '').replace(/"/g, '""')}"`,
      `"${(client.neighborhood || '').replace(/"/g, '""')}"`,
      `"${(client.city || '').replace(/"/g, '""')}"`,
      `"${(client.state || '').replace(/"/g, '""')}"`,
      `"${(client.zipCode || '').replace(/"/g, '""')}"`,
      '',
      client.status || '',
      client.ownerUserId || '',
      `"${(client.owner?.name || '').replace(/"/g, '""')}"`,
      client.createdAt ? new Date(client.createdAt).toISOString().split('T')[0] : '',
      client.updatedAt ? new Date(client.updatedAt).toISOString().split('T')[0] : '',
      `"${(client.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = [csvHeaders.join(','), ...csvRows.map(row => row.join(','))].join('\n');

    console.log("📤 [EXPORT] CSV generado correctamente, tamaño:", csvContent.length);

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="clientes_export_${new Date().toISOString().split('T')[0]}.csv"`);
    
    console.log("📤 [EXPORT] Enviando respuesta CSV...");
    return res.send(csvContent);
  } catch (err) {
    console.error("📤 [EXPORT] Error al exportar clientes:", err);
    return res.status(500).json({ error: "Error al exportar clientes", details: err.message });
  }
};

export const importClients = async (req: Request, res: Response): Promise<Response> => {
  const { companyId, id: userId } = req.user;
  const { previewOnly = false, selectedItems = [] } = req.body;
  
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No se enviaron archivos" });
    }

    const multer = require('multer');
    const csv = require('csv-parser');
    const fs = require('fs');
    const path = require('path');

    const results = [];
    const filePath = req.file.path;

    return new Promise((resolve, reject) => {
      fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (data) => {
          results.push(data);
        })
        .on('end', async () => {
          try {
            // **VALIDACIÓN Y PREVISUALIZACIÓN**
            if (previewOnly || selectedItems.length > 0) {
              const validatedData = [];
              
              for (let i = 0; i < results.length; i++) {
                const row = results[i];
                let error = null;
                
                try {
                  // Validações básicas
                  if (!row['Nombre'] && !row['nome']) {
                    error = "El nombre es obligatorio";
                  } else if (!row['E-mail'] && !row['email'] && !row['Teléfono'] && !row['telefone']) {
                    error = "E-mail o Se requiere teléfono";
                  } else {
                    // Validar el formato de correo electrónico si se proporciona
                    const email = row['E-mail'] || row['email'];
                    if (email && !email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                      error = "E-mail inválido";
                    }
                    
                    // Validar el número de teléfono si se proporciona
                    const phone = row['Teléfono'] || row['telefone'];
                    if (phone && phone.length < 8) {
                      error = "telefono muy corto";
                    }

                    // Validar tipo
                    const type = row['Tipo'] || row['tipo'] || 'person';
                    if (!['person', 'pf', 'pj'].includes(type.toLowerCase())) {
                      error = "El tipo debe ser 'PN' o 'PJ'";
                    }

                    // Validar documento si se proporciona
                    const document = row['Documento'] || row['documento'];
                    if (document && document.length < 8) {
                      error = "documento muy corto";
                    }
                  }
                } catch (validationError) {
                  error = validationError.message;
                }

                const clientData = {
                  index: i,
                  name: row['Nombre'] || row['nome'] || '',
                  companyName: row['nombre de empresa'] || row['nome_empresa'] || '',
                  type: row['Tipo'] || row['tipo'] || 'person',
                  document: row['Documento'] || row['documento'] || '',
                  email: row['E-mail'] || row['email'] || '',
                  phone: row['Teléfono'] || row['telefone'] || '',
                  address: row['DIRECCIÓN'] || row['endereco'] || '',
                  number: row['Número'] || row['numero'] || '',
                  neighborhood: row['Vecindario'] || row['bairro'] || '',
                  city: row['Ciudad'] || row['cidade'] || '',
                  state: row['Estado'] || row['estado'] || '',
                  zipCode: row['código postal'] || row['cep'] || '',
                  status: row['Estado'] || row['status'] || 'active',
                  ownerUserId: row['ID responsable'] || row['id_responsavel'] ? parseInt(row['ID responsable'] || row['id_responsavel']) : null,
                  notes: row['Notas'] || row['notas'] || '',
                  error
                };

                validatedData.push(clientData);
              }

              // Borrar archivo temporal
              fs.unlinkSync(filePath);

              return resolve(res.json({
                preview: true,
                data: validatedData,
                total: results.length,
                valid: validatedData.filter(item => !item.error).length,
                errors: validatedData.filter(item => item.error).length
              }));
            }

            // **IMPORTACIÓN REAL (si no es vista previa)**
            let imported = 0;
            let errors = [];

            // Processar apenas itens selecionados
            const itemsToProcess = selectedItems.length > 0 ? 
              selectedItems.map(index => results[index]) : 
              results;

            for (const row of itemsToProcess) {
              try {
                const clientData = {
                  companyId,
                  name: row['Nombre'] || row['nome'] || '',
                  companyName: row['nombre de empresa'] || row['nome_empresa'] || '',
                  type: row['Tipo'] || row['tipo'] || 'person',
                  document: row['Documento'] || row['documento'] || '',
                  email: row['E-mail'] || row['email'] || '',
                  phone: row['Teléfono'] || row['telefone'] || '',
                  address: row['DIRECCIÓN'] || row['endereco'] || '',
                  number: row['Número'] || row['numero'] || '',
                  neighborhood: row['Vecindario'] || row['bairro'] || '',
                  city: row['Ciudad'] || row['cidade'] || '',
                  state: row['Estado'] || row['estado'] || '',
                  zipCode: row['código postal'] || row['cep'] || '',
                  status: row['Estado'] || row['status'] || 'active',
                  ownerUserId: row['ID responsable'] || row['id_responsavel'] ? parseInt(row['ID responsable'] || row['id_responsavel']) : null,
                  notes: row['Notas'] || row['notas'] || '',
                  createdByUserId: Number(userId)
                };

                await CreateCrmClientService(clientData);
                imported++;
              } catch (error) {
                console.error(`Error al importar cliente ${row['Nombre']}:`, error);
                errors.push({
                  row: row['Nombre'] || 'Desconocido',
                  error: error.message
                });
              }
            }

            // Borrar archivo temporal
            fs.unlinkSync(filePath);

            return resolve(res.json({
              message: "Importación completada",
              total: itemsToProcess.length,
              imported,
              errors: errors.length,
              errorDetails: errors
            }));
          } catch (error) {
            fs.unlinkSync(filePath);
            return reject(res.status(500).json({ error: "Error al procesar el archivo" }));
          }
        })
        .on('error', (error) => {
          fs.unlinkSync(filePath);
          return reject(res.status(500).json({ error: "Error al leer el archivo CSV" }));
        });
    });
  } catch (err) {
    console.error("Error al importar clientes:", err);
    return res.status(500).json({ error: "Error al importar clientes" });
  }
};

export default {
  index,
  store,
  show,
  update,
  delete: remove,
  exportClients,
  importClients
};
