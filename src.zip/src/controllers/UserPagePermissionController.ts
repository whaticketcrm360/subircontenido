import { Request, Response } from "express";
import UserPagePermissionService from "../services/UserPagePermissionService";

class UserPagePermissionController {
  // Listar todas las páginas disponibles en el sistema.
  static async listAvailablePages(req: Request, res: Response) {
    try {
      const pages = UserPagePermissionService.getAvailablePages();
      
      // Organizar por grupos
      const groupedPages = pages.reduce((acc, page) => {
        if (!acc[page.group]) {
          acc[page.group] = [];
        }
        acc[page.group].push(page);
        return acc;
      }, {} as Record<string, typeof pages>);

      res.json({ pages: groupedPages });
    } catch (error) {
      console.error("Error al enumerar las páginas disponibles:", error);
      res.status(500).json({ error: "Error Interno del Servidor" });
    }
  }

  // Obtiene permisos de un usuario específico
  static async getUserPermissions(req: Request, res: Response) {
    try {
      const { userId } = req.params;
      
      if (!userId || isNaN(Number(userId))) {
        return res.status(400).json({ error: "ID de usuario no válido" });
      }

      const permissions = await UserPagePermissionService.getUserPagePermissions(Number(userId));
      res.json(permissions);
    } catch (error) {
      console.error("Error al obtener permisos de usuario:", error);
      if (error instanceof Error && error.message === "Usuario no encontrado") {
        return res.status(404).json({ error: "Usuario no encontrado" });
      }
      res.status(500).json({ error: "Error Interno del Servidor" });
    }
  }

  // Establece los permisos de un usuario
  static async setUserPermissions(req: Request, res: Response) {
    try {
      const { userId } = req.params;
      const { permissions, pagePermissionsMode } = req.body;

      if (!userId || isNaN(Number(userId))) {
        return res.status(400).json({ error: "ID de usuario no válido" });
      }

      if (!pagePermissionsMode || !["inherit", "custom"].includes(pagePermissionsMode)) {
        return res.status(400).json({ error: "Modo de permisos no válidos" });
      }

      if (!Array.isArray(permissions)) {
        return res.status(400).json({ error: "Los permisos deben ser una matriz." });
      }

      // Validação das permissões
      const availablePages = UserPagePermissionService.getAvailablePages();
      const availablePaths = new Set(availablePages.map(p => p.path));

      for (const permission of permissions) {
        if (!permission.pagePath || typeof permission.canAccess !== "boolean") {
          return res.status(400).json({ error: "Formato de permiso no válido" });
        }

        if (!availablePaths.has(permission.pagePath)) {
          return res.status(400).json({ error: `Página no válida: ${permission.pagePath}` });
        }
      }

      const result = await UserPagePermissionService.setUserPagePermissions({
        userId: Number(userId),
        permissions,
        pagePermissionsMode
      });

      res.json(result);
    } catch (error) {
      console.error("Error al configurar permisos de usuario:", error);
      if (error instanceof Error && error.message === "Usuario no encontrado") {
        return res.status(404).json({ error: "Usuario no encontrado" });
      }
      res.status(500).json({ error: "Error Interno del Servidor" });
    }
  }

  // Comprueba si un usuario tiene acceso a una página específica (punto final de utilidad)
  static async checkPageAccess(req: Request, res: Response) {
    try {
      const userId = req.user?.id;
      const { pagePath } = req.query;

      if (!userId) {
        return res.status(401).json({ error: "Usuario no autenticado" });
      }

      if (!pagePath || typeof pagePath !== "string") {
        return res.status(400).json({ error: "Ruta de página no válida" });
      }

      const canAccess = await UserPagePermissionService.canUserAccessPage(Number(userId), pagePath);
      res.json({ canAccess, pagePath });
    } catch (error) {
      console.error("Error al comprobar el acceso a la página:", error);
      res.status(500).json({ error: "Error Interno del Servidor" });
    }
  }

  // Obtiene páginas a las que un usuario puede acceder (para armar el menú)
  static async getUserAccessiblePages(req: Request, res: Response) {
    try {
      const userId = req.user?.id;

      if (!userId) {
        return res.status(401).json({ error: "Usuario no autenticado" });
      }

      const pages = await UserPagePermissionService.getUserAccessiblePages(Number(userId));
      
      // Organizar por grupos
      const groupedPages = pages.reduce((acc, page) => {
        if (!acc[page.group]) {
          acc[page.group] = [];
        }
        acc[page.group].push(page);
        return acc;
      }, {} as Record<string, typeof pages>);

      res.json({ pages: groupedPages });
    } catch (error) {
      console.error("Error al obtener páginas accesibles:", error);
      res.status(500).json({ error: "Error Interno del Servidor" });
    }
  }
}

export default UserPagePermissionController;
