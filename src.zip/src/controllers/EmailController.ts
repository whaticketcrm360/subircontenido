import { Request, Response } from "express";
import { SendMail } from "../helpers/SendMail";

export const sendCrmEmail = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { nome, email, telefone, empresa, segmento, mensagem } = req.body;

    // Armar HTML de correo electrónico
    const htmlContent = `
      <h2>Nueva solicitud de CRM personalizada</h2>
      <p><strong>Nombre:</strong> ${nome}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Teléfono:</strong> ${telefone}</p>
      <p><strong>Empresa:</strong> ${empresa}</p>
      <p><strong>Segmento:</strong> ${segmento}</p>
      <p><strong>Mensaje:</strong></p>
      <p>${mensagem}</p>
      <hr>
      <p><small>Enviado a través del formulario del panel</small></p>
    `;

    // Utilice la función SendMail existente
    await SendMail({
      to: "juanlopez@gmail.com",
      subject: `Pedido CRM - ${empresa}`,
      html: htmlContent
    });

    return res.status(200).json({ message: "Email enviado exitosamente!" });
  } catch (error) {
    console.error("Error al enviar email:", error);
    return res.status(500).json({ error: "Error al enviar email" });
  }
};
