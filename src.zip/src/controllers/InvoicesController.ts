import AppError from "../errors/AppError";
import UpdateInvoiceService from "../services/InvoicesService/UpdateInvoiceService";
import { Request, Response } from "express";

// SDKs de pago
import mercadopago from "mercadopago";
import Stripe from "stripe";
import paypal from "@paypal/checkout-server-sdk";

// Configuración Mercado Pago
mercadopago.configurations.setAccessToken(process.env.MERCADO_PAGO_ACCESS_TOKEN);

// Configuración Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2022-11-15" });

// Configuración PayPal
const payPalEnv = new paypal.core.SandboxEnvironment(
  process.env.PAYPAL_CLIENT_ID || "",
  process.env.PAYPAL_CLIENT_SECRET || ""
);
const payPalClient = new paypal.core.PayPalHttpClient(payPalEnv);

export const pay = async (req: Request, res: Response): Promise<Response> => {
  const { invoiceId, amount, description, dueDate, companyId, method } = req.body;
  const userId = req.user.id;

  try {
    // 1. Marcar factura como "pending"
    const invoice = await UpdateInvoiceService({
      id: invoiceId,
      status: "pending"
    });

    let paymentLink = "";

    if (method === "mercadopago") {
      // 2a. Crear preferencia en Mercado Pago
      const preference = {
        items: [{ title: description, quantity: 1, unit_price: amount }],
        back_urls: {
          success: `${process.env.FRONTEND_URL}/checkout/success`,
          failure: `${process.env.FRONTEND_URL}/checkout/failure`,
          pending: `${process.env.FRONTEND_URL}/checkout/pending`
        },
        auto_return: "approved",
        external_reference: invoiceId.toString()
      };
      const mpResponse = await mercadopago.preferences.create(preference);
      paymentLink = mpResponse.body.init_point;

    } else if (method === "stripe") {
      // 2b. Crear sesión de pago en Stripe
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: { name: description },
              unit_amount: Math.round(amount * 100), // en centavos
            },
            quantity: 1,
          },
        ],
        mode: "payment",
        success_url: `${process.env.FRONTEND_URL}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.FRONTEND_URL}/checkout/failure`,
        metadata: { invoiceId: invoiceId.toString() }
      });
      paymentLink = session.url || "";

    } else if (method === "paypal") {
      // 2c. Crear orden en PayPal
      const request = new paypal.orders.OrdersCreateRequest();
      request.prefer("return=representation");
      request.requestBody({
        intent: "CAPTURE",
        purchase_units: [{
          amount: { currency_code: "USD", value: amount.toFixed(2) },
          description
        }],
        application_context: {
          return_url: `${process.env.FRONTEND_URL}/checkout/success`,
          cancel_url: `${process.env.FRONTEND_URL}/checkout/failure`
        }
      });
      const order = await payPalClient.execute(request);
      paymentLink = order.result.links.find((l: any) => l.rel === "approve")?.href || "";
    } else {
      throw new AppError("Método de pago no soportado");
    }

    // 3. Devolver respuesta con el link de pago
    return res.status(200).json({
      success: true,
      invoiceId,
      paymentLink,
      amount,
      status: "pending",
      message: "Redirigiendo al pago..."
    });

  } catch (err: any) {
    throw new AppError("Error al procesar el pago: " + err.message);
  }
};