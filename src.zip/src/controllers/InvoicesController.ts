import { generatePaymentLink } from "../services/PaymentGatewayService/MultiGatewayService";

export const pay = async (req: Request, res: Response): Promise<Response> => {

  const { invoiceId, amount, description, provider } = req.body;

  try {

    const paymentLink = await generatePaymentLink(provider, {
      invoiceId,
      amount,
      description
    });

    return res.json({
      success: true,
      paymentLink
    });

  } catch (error) {
    throw new AppError("Error al generar pago: " + error.message);
  }
};