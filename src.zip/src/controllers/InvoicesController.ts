import * as Yup from "yup";
import { Request, Response } from "express";
import AppError from "../errors/AppError";
import Invoices from "../models/Invoices";
import Company from "../models/Company";
import Setting from "../models/Setting";
import { SendMailWithSettings } from "../helpers/SendMailWithSettings";
import ShowCompanyService from "../services/CompanyService/ShowCompanyService";
import FindCompaniesWhatsappService from "../services/CompanyService/FindCompaniesWhatsappService";
import { getWbot } from "../libs/wbot";
import moment from "moment";

import FindAllInvoiceService from "../services/InvoicesService/FindAllInvoiceService";
import ListInvoicesServices from "../services/InvoicesService/ListInvoicesServices";
import ShowInvoceService from "../services/InvoicesService/ShowInvoiceService";
import UpdateInvoiceService from "../services/InvoicesService/UpdateInvoiceService";
import DeleteInvoiceService from "../services/InvoicesService/DeleteInvoiceService";
import CreateInvoiceService from "../services/InvoicesService/CreateInvoiceService";

type IndexQuery = {
  searchParam: string;
  pageNumber: string;
};

type StoreInvoiceData = {
  companyId: number;
  dueDate: string;
  detail: string;
  status: string;
  value: number;
  users: number;
  connections: number;
  queues: number;
  useWhatsapp: boolean;
  useFacebook: boolean;
  useInstagram: boolean;
  useCampaigns: boolean;
  useSchedules: boolean;
  useInternalChat: boolean;
  useExternalApi: boolean;
  linkInvoice: string;
};

type UpdateInvoiceData = {
  status: string;
  id?: string;
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { searchParam, pageNumber } = req.query as IndexQuery;

  const { invoices, count, hasMore } = await ListInvoicesServices({
    searchParam,
    pageNumber
  });

  return res.json({ invoices, count, hasMore });
};

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { id } = req.params;

  const invoice = await ShowInvoceService(id);

  return res.status(200).json(invoice);
};


export const store = async (req: Request, res: Response): Promise<Response> => {
  const newPlan: StoreInvoiceData = req.body;

  const plan = await CreateInvoiceService(newPlan);

  return res.status(200).json(plan);
};

export const list = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;

  // Company 1 (super admin) vê todas as faturas
  if (+companyId === 1) {
    const allInvoices = await Invoices.findAll({
      include: [{ model: Company, as: "company", attributes: ["id", "name"] }],
      order: [["id", "ASC"]]
    });
    return res.status(200).json(allInvoices);
  }

  const invoice: Invoices[] = await FindAllInvoiceService(+companyId);

  return res.status(200).json(invoice);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const InvoiceData: UpdateInvoiceData = req.body;

  const schema = Yup.object().shape({
    name: Yup.string()
  });

  try {
    await schema.validate(InvoiceData);
  } catch (err) {
    throw new AppError(err.message);
  }

  const { id, status } = InvoiceData;

  const plan = await UpdateInvoiceService({
    id,
    status,

  });

  // const io = getIO();
  // io.of(companyId.toString())
  // .emit("plan", {
  //   action: "update",
  //   plan
  // });

  return res.status(200).json(plan);
};
export const pay = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { invoiceId, amount, description, dueDate, companyId } = req.body;
  const userId = req.user.id; // Corregido: usar req.user.id

  try {
    // Aquí implementarías la integración de la pasarela de pago.
    // Por ahora, simulemos el pago.
    
    // 1. Actualizar el estado de la factura a "pagada"
    const invoice = await UpdateInvoiceService({
      id: invoiceId,
      status: "paid"
    });

    // 2. Generar enlace de pago (simulado)
    const paymentLink = `https://checkout.pagamento.com.br/pay/${invoiceId}`;
    
    // 3. Detalles de pago de devolución
    return res.status(200).json({
      success: true,
      invoiceId,
      paymentLink,
      amount,
      status: "paid",
      message: "Pago procesado exitosamente"
    });
  } catch (err) {
    throw new AppError("Error al procesar el pago: " + err.message);
  }
};

export const adminManualPay = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId } = req.user;

  if (companyId !== 1) {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }

  const { id } = req.params;

  const invoice = await Invoices.findByPk(id);

  if (!invoice) {
    throw new AppError("ERR_NO_INVOICE_FOUND", 404);
  }

  await invoice.update({ status: "paid" });

  // Ampliar la fecha de vencimiento de la empresa 30 días a partir de hoy
  if (invoice.companyId) {
    const Company = require("../models/Company").default;
    const company = await Company.findByPk(invoice.companyId);
    if (company) {
      const moment = require("moment");
      const currentDueDate = moment(company.dueDate);
      const today = moment();
      const baseDate = currentDueDate.isAfter(today) ? currentDueDate : today;
      const newDueDate = baseDate.add(30, "days").format("YYYY-MM-DD");
      await company.update({ dueDate: newDueDate });
    }
  }

  return res.status(200).json({
    message: "¡Factura marcada como pagada exitosamente!",
    invoice
  });
};

const formatPhoneToWhatsappJid = (rawPhone?: string): string | null => {
  if (!rawPhone) return null;

  const digits = rawPhone.replace(/\D/g, "");
  if (!digits) return null;

  return digits + "@s.whatsapp.net";
};

export const sendBillingNotification = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId } = req.user;

  if (companyId !== 1) {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }

  const { id } = req.params;

  const invoice = await Invoices.findByPk(id, {
    include: [{ model: Company, as: "company" }]
  });

  if (!invoice) {
    throw new AppError("ERR_NO_INVOICE_FOUND", 404);
  }

  const targetCompany = invoice.company;
  if (!targetCompany) {
    throw new AppError("ERR_COMPANY_NOT_FOUND", 404);
  }

  let appName = "Sistema";
  try {
    const setting = await Setting.findOne({
      where: { companyId: 1, key: "appName" }
    });
    appName = setting?.value || "Sistema";
  } catch (e) {}

  const dueDate = moment(invoice.dueDate).format("DD/MM/YYYY");
  const value = Number(invoice.value).toLocaleString("es", {
    style: "currency",
    currency: "USD"
  });

  // Determinar el tipo de facturación según la fecha de vencimiento
  const hoje = moment().startOf("day");
  const venc = moment(invoice.dueDate).startOf("day");
  const dias = venc.diff(hoje, "days");

  let settingKey = "invoiceMsgAviso"; // antes del vencimiento
  if (dias < 0) {
    settingKey = "invoiceMsgAtrasada"; // derrotado
  } else if (dias === 0) {
    settingKey = "invoiceMsgDia"; // gana hoy
  }

  // Buscar plantilla configurable
  let msgTemplate = "";
  try {
    const msgSetting = await Setting.findOne({
      where: { companyId: 1, key: settingKey }
    });
    msgTemplate = msgSetting?.value || "";
  } catch (e) {}

  // Función para reemplazar variables en la plantilla.
  const replaceVars = (text: string): string => {
    return text
      .replace(/\{empresa\}/g, targetCompany.name || "")
      .replace(/\{plano\}/g, invoice.detail || "")
      .replace(/\{valor\}/g, value)
      .replace(/\{vencimento\}/g, dueDate)
      .replace(/\{link\}/g, "");
  };

  // Mensaje predeterminado si no hay ninguna plantilla configurada
  const defaultWhatsappBody = `*Aviso de facturación - ${appName}*\n\nHola *${targetCompany.name}*,\n\nHemos identificado que la siguiente factura está abierta.:\n\n*Detalles:* ${invoice.detail}\n*Valor:* ${value}\n*Vencimiento:* ${dueDate}\n\nPor favor liquide el pago lo antes posible para evitar la suspensión de los servicios.\n\nSi tiene alguna pregunta, comuníquese con nosotros.\n\Atentamente,\n*${appName}*`;

  const whatsappBody = msgTemplate ? replaceVars(msgTemplate) : defaultWhatsappBody;

  const results = { email: false, whatsapp: false };

  // Enviar correo electrónico de facturación
  if (targetCompany.email) {
    try {
      const emailBody = `
        <h2>Aviso de facturación - ${appName}</h2>
        <p>Hola <strong>${targetCompany.name}</strong>,</p>
        <p>Hemos identificado que la siguiente factura está abierta.:</p>
        <table style="border-collapse: collapse; margin: 16px 0;">
          <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Detalles</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${invoice.detail}</td></tr>
          <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Valor</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${value}</td></tr>
          <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Vencimiento</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${dueDate}</td></tr>
        </table>
        <p>Por favor liquide el pago lo antes posible para evitar la suspensión de los servicios.</p>
        <p>Si tiene alguna pregunta, comuníquese con nosotros.</p>
        <br>
        <p>Tuyo sinceramente,<br><strong>${appName}</strong></p>
      `;

      const sent = await SendMailWithSettings({
        to: targetCompany.email,
        subject: `Aviso de facturación - Factura ${invoice.detail} - ${appName}`,
        html: emailBody
      });
      results.email = sent;
    } catch (error) {
      console.error("Error al enviar la facturación email:", error);
    }
  }

  // Enviar facturación WhatsApp
  if (targetCompany.phone) {
    try {
      const adminCompany = await ShowCompanyService(1);
      const whatsappCompany = await FindCompaniesWhatsappService(adminCompany.id);
      const firstWhatsapp = whatsappCompany.whatsapps[0];
      const phoneJid = formatPhoneToWhatsappJid(targetCompany.phone);

      if (firstWhatsapp?.status === "CONNECTED" && phoneJid) {
        const wbot = getWbot(firstWhatsapp.id);

        const sendOptions: any = { createChat: false };
        await wbot.sendMessage(phoneJid, { text: whatsappBody }, sendOptions);
        results.whatsapp = true;
      }
    } catch (error) {
      console.error("Error al enviar la facturación WhatsApp:", error);
    }
  }

  return res.status(200).json({
    message: "¡Notificación de facturación enviada!",
    results
  });
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { id } = req.params;

  const invoice = await DeleteInvoiceService(id);

  return res.status(200).json(invoice);
}; 
