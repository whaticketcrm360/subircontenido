import * as Yup from "yup";
import { Request, Response } from "express";
import AppError from "../errors/AppError";

// ← UN SOLO import de Invoices
import Invoices from "../models/Invoices";

import FindAllInvoiceService from "../services/InvoicesService/FindAllInvoiceService";
import ListInvoicesServices from "../services/InvoicesService/ListInvoicesServices";
import ShowInvoceService from "../services/InvoicesService/ShowInvoiceService";
import UpdateInvoiceService from "../services/InvoicesService/UpdateInvoiceService";
import DeleteInvoiceService from "../services/InvoicesService/DeleteInvoiceService";
import CreateInvoiceService from "../services/InvoicesService/CreateInvoiceService";

// ← Imports del servicio real de pagos
import {
  generatePaymentLink,
  getCompanyPaymentToken
} from "../services/PaymentGatewayService";

type IndexQuery = {
  searchParam: string;
  pageNumber: string;
};

type StoreInvoiceData = {
  companyId: number;
  dueDate: string;
  detail: string;
  status: string;
  value: number;
  users: number;
  connections: number;
  queues: number;
  useWhatsapp: boolean;
  useFacebook: boolean;
  useInstagram: boolean;
  useCampaigns: boolean;
  useSchedules: boolean;
  useInternalChat: boolean;
  useExternalApi: boolean;
  linkInvoice: string;
};

type UpdateInvoiceData = {
  status: string;
  id?: string;
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { searchParam, pageNumber } = req.query as IndexQuery;
  const { invoices, count, hasMore } = await ListInvoicesServices({
    searchParam,
    pageNumber
  });
  return res.json({ invoices, count, hasMore });
};

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { id } = req.params;
  const invoice = await ShowInvoceService(id);
  return res.status(200).json(invoice);
};

export const store = async (req: Request, res: Response): Promise<Response> => {
  const newPlan: StoreInvoiceData = req.body;
  const plan = await CreateInvoiceService(newPlan);
  return res.status(200).json(plan);
};

export const list = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const invoice: Invoices[] = await FindAllInvoiceService(+companyId);
  return res.status(200).json(invoice);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const InvoiceData: UpdateInvoiceData = req.body;

  const schema = Yup.object().shape({
    name: Yup.string()
  });

  try {
    await schema.validate(InvoiceData);
  } catch (err) {
    throw new AppError(err.message);
  }

  const { id, status } = InvoiceData;
  const plan = await UpdateInvoiceService({ id, status });
  return res.status(200).json(plan);
};

// ← FUNCIÓN PAY REAL (no simulada)
export const pay = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { invoiceId } = req.body;
  const { companyId } = req.user;

  try {
    // PASO 1: Buscar la factura y verificar que pertenece a esta empresa
    const invoice = await Invoices.findOne({
      where: { id: invoiceId, companyId }
    });

    if (!invoice) {
      throw new AppError("Factura no encontrada.", 404);
    }

    // PASO 2: Detectar proveedor configurado (Asaas primero, luego MercadoPago)
    let provider: "asaas" | "mercadopago" | null = null;

    try {
      await getCompanyPaymentToken(Number(companyId), "asaas");
      provider = "asaas";
    } catch {
      try {
        await getCompanyPaymentToken(Number(companyId), "mercadopago");
        provider = "mercadopago";
      } catch {
        provider = null;
      }
    }

    if (!provider) {
      throw new AppError(
        "No hay pasarela de pago configurada. " +
        "Configure Asaas o MercadoPago en los ajustes de la empresa.",
        400
      );
    }

    // PASO 3: Mapear campos del modelo Invoices → FinanceiroFatura
    const invoiceAsFinanceiro = {
      id:                invoice.id,
      companyId:         Number(invoice.companyId),
      valor:             Number(invoice.value),
      descricao:         invoice.detail || `Factura #${invoice.id}`,
      dataVencimento:    invoice.dueDate,
      clientId:          (invoice as any).clientId || Number(invoice.companyId),
      paymentExternalId: (invoice as any).paymentExternalId || null,
      paymentProvider:   (invoice as any).paymentProvider || null,
    } as any;

    // PASO 4: Llamar al servicio real — genera el link en Asaas o MercadoPago
    const { paymentLink, paymentExternalId } = await generatePaymentLink({
      invoice: invoiceAsFinanceiro,
      provider
    });

    if (!paymentLink) {
      throw new AppError(
        "El proveedor no devolvió un link válido. " +
        "Verifique la configuración del token.",
        500
      );
    }

    // PASO 5: Guardar paymentExternalId y provider en la factura
    // Status queda "pending" — cambia a "paid" solo cuando llegue el webhook
    await invoice.update({
      paymentExternalId: paymentExternalId || null,
      paymentProvider:   provider,
      status:            "pending"
    } as any);

    // PASO 6: Responder con el link real
    return res.status(200).json({
      success:     true,
      invoiceId:   invoice.id,
      paymentLink: paymentLink,
      provider:    provider,
      status:      "pending",
      message:     `Link generado correctamente con ${provider}.`
    });

  } catch (err) {
    if (err instanceof AppError) throw err;
    throw new AppError("Error al procesar el pago: " + err.message);
  }
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { id } = req.params;
  const invoice = await DeleteInvoiceService(id);
  return res.status(200).json(invoice);
};